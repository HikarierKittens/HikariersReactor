import assert from 'node:assert/strict';
import { test } from 'node:test';
import { CONFIG } from '../src/data/config';
import { exportRecoveryCheckpoint, hasRecoveryCheckpoint, readRecoveryCheckpoint, saveRecoveryCheckpoint } from '../src/state/recovery';
import type { RecoveryKind, RecoveryStorage } from '../src/state/recovery';

function memory() {
  const values = new Map<string, string>([[CONFIG.saveKey, 'active save untouched']]);
  const writes: string[] = [];
  const storage: RecoveryStorage = {
    getItem: key => values.get(key) ?? null,
    setItem(key, value) { writes.push(key); values.set(key, value); },
  };
  return { values, writes, storage };
}
const key = (kind: RecoveryKind) => `${CONFIG.saveKey}:recovery:${kind}`;
// Raw pre-migration data deliberately avoids coupling backup tests to current schemas.
const baseline = () => ({ version: 29, resources: { wood: 0 }, buildings: { hut: 0 }, tech: [], lastSaved: 12345, logs: [], legacy: { retained: true } });

test('upgrade persists a detached pre-v30 baseline once without touching active storage', () => {
  const env = memory();
  const state = baseline();
  const original = JSON.stringify(state);
  assert.deepEqual(saveRecoveryCheckpoint(state, 'upgrade', env.storage), { ok: true });
  assert.equal(JSON.stringify(state), original);
  assert.deepEqual(readRecoveryCheckpoint('upgrade', env.storage), state);
  assert.equal(exportRecoveryCheckpoint('upgrade', env.storage), original);
  const envelope = JSON.parse(env.values.get(key('upgrade'))!);
  assert.equal(envelope.version, 1);
  assert.equal(envelope.kind, 'upgrade');
  assert.equal(envelope.state.version, 29);
  state.resources.wood = 321;
  assert.equal(saveRecoveryCheckpoint(state, 'upgrade', env.storage).ok, false);
  assert.equal(exportRecoveryCheckpoint('upgrade', env.storage), original);
  const read = readRecoveryCheckpoint('upgrade', env.storage) as typeof state;
  read.resources.wood = 999;
  assert.equal(exportRecoveryCheckpoint('upgrade', env.storage), original);
  assert.equal(env.values.get(CONFIG.saveKey), 'active save untouched');
  assert.deepEqual(env.writes, [key('upgrade')]);
});

test('explicit ending requests replace ending only, retaining the upgrade baseline', () => {
  const env = memory();
  const state = baseline();
  saveRecoveryCheckpoint(state, 'upgrade', env.storage);
  const upgrade = env.values.get(key('upgrade'));
  assert.equal(saveRecoveryCheckpoint(state, 'ending', env.storage).ok, true);
  state.resources.wood = 42;
  state.version = 30;
  assert.equal(saveRecoveryCheckpoint(state, 'ending', env.storage).ok, true);
  assert.deepEqual(readRecoveryCheckpoint('ending', env.storage), state);
  assert.equal(env.values.get(key('upgrade')), upgrade);
  assert.equal(env.values.get(CONFIG.saveKey), 'active save untouched');
});

test('storage read and quota failures are contained and never clear a prior checkpoint', () => {
  for (const kind of ['upgrade', 'ending'] as const) {
    const env = memory();
    const unreadable: RecoveryStorage = { getItem() { throw Error('denied'); }, setItem() { assert.fail('must not write after a failed read'); } };
    assert.equal(saveRecoveryCheckpoint(baseline(), kind, unreadable).ok, false);
    assert.equal(readRecoveryCheckpoint(kind, unreadable), null);
    assert.equal(exportRecoveryCheckpoint(kind, unreadable), null);
    assert.equal(hasRecoveryCheckpoint(kind, unreadable), false);
    if (kind === 'ending') saveRecoveryCheckpoint(baseline(), kind, env.storage);
    const previous = [...env.values];
    const quota: RecoveryStorage = { getItem: env.storage.getItem, setItem() { throw Error('quota'); } };
    assert.equal(saveRecoveryCheckpoint(baseline(), kind, quota).ok, false);
    assert.deepEqual([...env.values], previous);
  }
});

test('missing or access-denied global localStorage fails safely', t => {
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
  t.after(() => {
    if (descriptor) Object.defineProperty(globalThis, 'localStorage', descriptor);
    else Reflect.deleteProperty(globalThis, 'localStorage');
  });
  for (const replacement of [{ configurable: true, value: undefined }, { configurable: true, get() { throw Error('SecurityError'); } }]) {
    Object.defineProperty(globalThis, 'localStorage', replacement);
    assert.equal(saveRecoveryCheckpoint(baseline(), 'upgrade').ok, false);
    assert.equal(readRecoveryCheckpoint('upgrade'), null);
    assert.equal(exportRecoveryCheckpoint('upgrade'), null);
    assert.equal(hasRecoveryCheckpoint('upgrade'), false);
  }
});

test('malformed or mismatched envelopes are unreadable and never overwritten by upgrade', () => {
  const env = memory();
  saveRecoveryCheckpoint(baseline(), 'upgrade', env.storage);
  const valid = JSON.parse(env.values.get(key('upgrade'))!);
  for (const text of ['{', 'null', '[]', '{}', JSON.stringify(baseline()), JSON.stringify({ ...valid, version: 2 }), JSON.stringify({ ...valid, kind: 'ending' }), JSON.stringify({ ...valid, state: { version: 29, resources: [], buildings: {}, tech: [] } }), JSON.stringify({ ...valid, state: { ...valid.state, version: 30 } })]) {
    env.values.set(key('upgrade'), text);
    assert.equal(readRecoveryCheckpoint('upgrade', env.storage), null);
    assert.equal(exportRecoveryCheckpoint('upgrade', env.storage), null);
    assert.equal(hasRecoveryCheckpoint('upgrade', env.storage), false);
    assert.equal(saveRecoveryCheckpoint(baseline(), 'upgrade', env.storage).ok, false);
    assert.equal(env.values.get(key('upgrade')), text);
  }
});

test('invalid source data is rejected before serialization can drop or coerce it', () => {
  const cyclic: Record<string, unknown> = {};
  cyclic.self = cyclic;
  const getter = Object.defineProperty({}, 'secret', { enumerable: true, get() { assert.fail('getter must not run'); } });
  const toJSON = { toJSON() { assert.fail('toJSON must not run'); } };
  for (const invalid of [undefined, NaN, Infinity, 1n, () => 1, Symbol('value'), new Date(), new Map(), cyclic, getter, toJSON, [, 1]]) {
    const env = memory();
    const source: Record<string, unknown> = { ...baseline(), invalid };
    assert.equal(saveRecoveryCheckpoint(source, 'ending', env.storage).ok, false);
    assert.deepEqual(env.writes, []);
    assert.equal(env.values.get(CONFIG.saveKey), 'active save untouched');
  }
  for (const source of [{ ...baseline(), resources: { wood: 'bad' } }, { ...baseline(), version: 30 }]) {
    assert.equal(saveRecoveryCheckpoint(source, 'upgrade', memory().storage).ok, false);
  }
});

test('legacy raw records and command-like strings remain inert JSON data', () => {
  const env = memory();
  const source: Record<string, unknown> = JSON.parse(JSON.stringify(baseline()));
  source.command = 'globalThis.compromised = true; process.exit(1)';
  assert.equal(saveRecoveryCheckpoint(source, 'upgrade', env.storage).ok, true);
  assert.equal(hasRecoveryCheckpoint('upgrade', env.storage), true);
  assert.deepEqual(JSON.parse(exportRecoveryCheckpoint('upgrade', env.storage)!), source);
});
