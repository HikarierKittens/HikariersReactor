/** The fourth world keeps its gate and hosts a local visual-terminal prototype. */
export async function runStageFourAcceptance({ store, click, flush, log, $, $$ }) {
  const { createMilestoneState } = await import('/tests/fixtures/milestones.ts');
  const { createInitialState } = await import('/src/state/create-state.ts');
  const { CONFIG } = await import('/src/data/config.ts');
  const { isStageFourEntranceUnlocked } = await import('/src/simulation/stage-four.ts');
  const press = async element => { if (!element || element.disabled) throw Error('Missing world navigation target'); click(element); await flush(); };
  const install = async state => { state.settings.paused = true; store.mutate(current => Object.assign(current, state)); await flush(); };
  const host = () => {
    const state = createMilestoneState('postBeacon');
    for (const id of ['artificialIntelligenceII', 'overclocking13', 'penroseTheory']) if (!state.tech.includes(id)) state.tech.push(id);
    state.stageThree.coreActivated = true;
    state.buildings.massEjector = 1;
    return state;
  };

  await install(createInitialState(CONFIG.version, 600, Date.now()));
  await press($('[data-tab="buildings"]'));
  log(!$('[data-tab="stageFour"]') && !$('[data-world-view="stageFour"]') && $$('[data-world-view]').length === 1 && !$('.stage-four'), '新档世界仅显示地面，第四子页面未解锁时隐藏');
  const unlocked = host();
  log(isStageFourEntranceUnlocked(unlocked), '原入口前置满足时解锁第四世界');
  for (const id of ['artificialIntelligenceII', 'overclocking13', 'penroseTheory']) {
    const locked = host(); locked.tech = locked.tech.filter(tech => tech !== id);
    log(!isStageFourEntranceUnlocked(locked), `第四世界保留科技前置${id}`);
  }
  const inactive = host(); inactive.stageThree.coreActivated = false;
  const noEjector = host(); noEjector.buildings.massEjector = 0;
  log(!isStageFourEntranceUnlocked(inactive) && !isStageFourEntranceUnlocked(noEjector), '第四世界仍需核心实际启动及质量喷射器');
  await install(unlocked);
  log($$('[data-world-view]')[3]?.textContent.trim() === 'world_exection', 'world_exection保留为世界第四个子页面标题');
  await press($('[data-world-view="stageFour"]'));
  const panel = $('.stage-four');
  const action = name => $(`[data-terminal-action="${name}"]`);
  log(!!panel && !!action('scan') && !$('[data-terminal-node="signal"]'), '终端初始仅提供扫描，未知节点未发现');
  const snapshot = JSON.stringify(store.state());
  await press(action('scan'));
  log(!!$('[data-terminal-node="signal"]'), '扫描发现未知信号');
  await press(action('inspect'));
  await press(action('connect'));
  log(!!$('[data-terminal-edge="signal-archive"]') && !!$('[data-terminal-node="relay"]'), '建立直连并发现档案及中继');
  await press(action('read'));
  log(panel.textContent.includes('拒绝'), '直连读取被拒绝，不是无条件点亮');
  await press(action('route-relay'));
  log(!!$('[data-terminal-edge="signal-relay"]') && !!$('[data-terminal-edge="relay-archive"]') && !$('[data-terminal-edge="signal-archive"]'), '重接中继改变实际线路');
  await press(action('read'));
  log(panel.textContent.includes('片段'), '中继线路可读取档案片段');
  await press(action('route-direct'));
  log(!!$('[data-terminal-edge="signal-archive"]') && !$('[data-terminal-edge="relay-archive"]'), '可切回直连而非一次性进度条');
  await press(action('disconnect'));
  log(!$('[data-terminal-edge="signal-archive"]') && (!action('read') || action('read').disabled), '断开切断远端访问');
  await press(action('connect'));
  await press(action('reset'));
  log(!$('[data-terminal-node="signal"]') && !!action('scan'), '重置原型恢复未扫描状态');
  log(JSON.stringify(store.state()) === snapshot && !('stageFour' in store.state()) && !$('#stageFourEndingDialog'), '原型不改变存档资源或添加结局');
  await press(action('scan'));
  await press($('[data-world-view="home"]'));
  await press($('[data-world-view="stageFour"]'));
  log(!$('[data-terminal-node="signal"]'), '离开页面清除临时会话，与页面提示一致');
  await install(createInitialState(CONFIG.version, 600, Date.now()));
  log(!$('[data-world-view="stageFour"]') && !$('.stage-four') && $('[data-world-view="home"]')?.classList.contains('active'), '读入未解锁进度后隐藏第四世界并返回地面');
}
