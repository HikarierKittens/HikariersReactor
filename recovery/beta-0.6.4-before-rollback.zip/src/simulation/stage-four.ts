import type { GameState } from '../types/state';

/** The empty fourth world subpage retains its original main-world prerequisites. */
export function isStageFourEntranceUnlocked(state: Pick<GameState, 'tech' | 'stageThree' | 'buildings'>): boolean {
  return state.tech.includes('artificialIntelligenceII')
    && state.tech.includes('overclocking13')
    && state.tech.includes('penroseTheory')
    && state.stageThree.coreActivated
    && state.buildings.massEjector >= 1;
}
