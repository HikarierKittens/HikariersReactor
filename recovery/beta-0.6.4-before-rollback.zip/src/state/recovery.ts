import { CONFIG } from '../data/config';
import type { GameState } from '../types/state';

export type RecoveryKind = 'upgrade' | 'ending';
export interface RecoveryStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}
export interface RecoveryResult { ok: boolean; error?: string }

const FORMAT = 'meow-civilization-recovery';
const ENVELOPE_VERSION = 1;

function keyFor(kind: RecoveryKind): string {
  if (kind !== 'upgrade' && kind !== 'ending') throw Error('Invalid recovery checkpoint kind.');
  return `${CONFIG.saveKey}:recovery:${kind}`;
}

function resolveStorage(storage?: RecoveryStorage): RecoveryStorage {
  const resolved = storage ?? globalThis.localStorage;
  if (!resolved || typeof resolved.getItem !== 'function' || typeof resolved.setItem !== 'function') {
    throw Error('Recovery storage is unavailable.');
  }
  return resolved;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype: unknown = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

/** Copy only JSON data, without invoking getters/toJSON or silently dropping values. */
function cloneJson(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null || (!Array.isArray(value) && !isRecord(value))) {
    throw Error('Recovery checkpoint contains non-JSON data.');
  }
  if (ancestors.has(value)) throw Error('Recovery checkpoint contains circular data.');
  ancestors.add(value);
  try {
    const result: Record<string, unknown> | unknown[] = Array.isArray(value) ? [] : {};
    for (const key of Reflect.ownKeys(value)) {
      if (Array.isArray(value) && key === 'length') continue;
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (typeof key !== 'string' || !descriptor || !descriptor.enumerable || !('value' in descriptor)) {
        throw Error('Recovery checkpoint contains unsupported properties.');
      }
      if (Array.isArray(value) && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) >= value.length)) {
        throw Error('Recovery checkpoint contains invalid array properties.');
      }
      Object.defineProperty(result, key, { value: cloneJson(descriptor.value, ancestors), enumerable: true, configurable: true, writable: true });
    }
    if (Array.isArray(value) && Object.keys(result).length !== value.length) throw Error('Recovery checkpoint contains sparse arrays.');
    return result;
  } finally {
    ancestors.delete(value);
  }
}

/** Structural screening only: restore must still pass runtime.replaceState validation. */
function isSave(value: unknown, kind: RecoveryKind): value is Record<string, unknown> {
  if (!isRecord(value) || !Number.isSafeInteger(value.version) || (value.version as number) < 12) return false;
  if (kind === 'upgrade' && (value.version as number) >= 30) return false;
  if (!isRecord(value.resources) || !isRecord(value.buildings) || !Array.isArray(value.tech)) return false;
  return Object.values(value.resources).every(n => typeof n === 'number' && Number.isFinite(n))
    && Object.values(value.buildings).every(n => typeof n === 'number' && Number.isFinite(n))
    && value.tech.every(id => typeof id === 'string');
}

/** Separate keys only. Upgrade is write-once, even if an existing backup is corrupt. */
export function saveRecoveryCheckpoint(state: GameState | Record<string, unknown>, kind: RecoveryKind, storage?: RecoveryStorage): RecoveryResult {
  try {
    const key = keyFor(kind);
    const target = resolveStorage(storage);
    // Read failures must not be mistaken for an empty slot, including for ending saves.
    const existing = target.getItem(key);
    if (kind === 'upgrade' && existing !== null) {
      return { ok: false, error: 'The original upgrade checkpoint already exists and was preserved.' };
    }
    const snapshot = cloneJson(state);
    if (!isSave(snapshot, kind)) return { ok: false, error: 'Invalid recovery save data.' };
    const text = JSON.stringify({ format: FORMAT, version: ENVELOPE_VERSION, kind, state: snapshot });
    // Finish serialization and parsing before the sole storage mutation.
    JSON.parse(text);
    target.setItem(key, text);
    return { ok: true };
  } catch {
    return { ok: false, error: 'Unable to save recovery checkpoint; storage is unavailable or the data is invalid.' };
  }
}

/** Returns detached, untrusted save data; never migrates or changes active storage. */
export function readRecoveryCheckpoint(kind: RecoveryKind, storage?: RecoveryStorage): unknown | null {
  try {
    const text = resolveStorage(storage).getItem(keyFor(kind));
    if (text === null) return null;
    const envelope: unknown = JSON.parse(text);
    if (!isRecord(envelope) || envelope.format !== FORMAT || envelope.version !== ENVELOPE_VERSION || envelope.kind !== kind) return null;
    const snapshot = cloneJson(envelope.state);
    return isSave(snapshot, kind) ? snapshot : null;
  } catch {
    return null;
  }
}

/** Export the raw save, not the envelope, for the normal validated import path. */
export function exportRecoveryCheckpoint(kind: RecoveryKind, storage?: RecoveryStorage): string | null {
  const state = readRecoveryCheckpoint(kind, storage);
  return state === null ? null : JSON.stringify(state);
}

export function hasRecoveryCheckpoint(kind: RecoveryKind, storage?: RecoveryStorage): boolean {
  return readRecoveryCheckpoint(kind, storage) !== null;
}
