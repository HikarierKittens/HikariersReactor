<script setup lang="ts">
import { computed, ref } from 'vue'

type NodeId = 'local' | 'signal' | 'relay' | 'archive'
type RecordEntry = { id: number; text: string }
const scanned = ref(false)
const discovered = ref(false)
const connected = ref(false)
const route = ref<'direct' | 'relay'>('direct')
const selected = ref<NodeId>('local')
const fragment = ref(false)
const message = ref('本地终端已就绪。扫描附近的未知信号。')
let sequence = 1
const records = ref<RecordEntry[]>([{ id: 1, text: '本地会话启动 · 等待扫描' }])
const mode = computed(() => connected.value ? route.value : 'disconnected')
const labels: Record<NodeId, string> = { local: '本地终端', signal: '未知信号', relay: '隔离中继', archive: '封存档案' }
const canInspect = computed(() => selected.value === 'local' || (selected.value === 'signal' && scanned.value) || (discovered.value && connected.value))
const edges = computed(() => {
  if (!connected.value) return []
  const common = [{ id: 'local-signal', d: 'M 17 53 L 43 53' }]
  return route.value === 'direct'
    ? [...common, { id: 'signal-archive', d: 'M 43 53 L 82 53' }]
    : [...common, { id: 'signal-relay', d: 'M 43 53 L 64 23' }, { id: 'relay-archive', d: 'M 64 23 L 82 53' }]
})
function record(text: string) {
  message.value = text
  records.value = [...records.value, { id: ++sequence, text }].slice(-8)
}
function scan() {
  if (scanned.value) return
  scanned.value = true
  selected.value = 'signal'
  record('扫描完成：发现未知信号。可检查或建立连接。')
}
function inspect() {
  if (!canInspect.value) return
  const hints: Record<NodeId, string> = {
    local: '本地终端：只保留本次会话记录，不向外部发送数据。',
    signal: '信号后方有两个目标。建立连接后可查看实际路由。',
    relay: '中继可隔离来源标识。将路径改为经由中继，再读取档案。',
    archive: '档案拒绝直连来源；需要经过隔离中继的访问路径。',
  }
  record(hints[selected.value])
}
function connect() {
  if (!scanned.value || connected.value) return
  connected.value = true
  discovered.value = true
  route.value = 'direct'
  selected.value = 'archive'
  record('连接建立：发现隔离中继与封存档案。当前使用直连路径。')
}
function rewire(next: 'direct' | 'relay') {
  if (!connected.value || next === route.value) return
  route.value = next
  record(next === 'relay' ? '路径已改接：信号 → 隔离中继 → 档案。' : '路径已改接：信号 → 档案。直连来源未隔离。')
}
function readArchive() {
  if (!connected.value || !discovered.value) return
  selected.value = 'archive'
  if (route.value === 'direct') {
    record('ACCESS DENIED · 直连来源被拒绝。检查隔离中继以寻找路径。')
    return
  }
  fragment.value = true
  record('读取成功：片段 01 已保留在本地会话。')
}
function disconnect() {
  if (!connected.value) return
  connected.value = false
  selected.value = 'signal'
  record('连接已断开：远端访问关闭；发现记录与已读片段保留。')
}
function reset() {
  scanned.value = false
  discovered.value = false
  connected.value = false
  route.value = 'direct'
  selected.value = 'local'
  fragment.value = false
  sequence = 1
  message.value = '本地终端已就绪。扫描附近的未知信号。'
  records.value = [{ id: 1, text: '本地会话重置 · 等待扫描' }]
}
</script>

<template>
  <section class="stage-four terminal" :data-terminal-mode="mode" aria-label="world_exection 数字终端原型">
    <header class="terminal-header">
      <div>
        <p class="eyebrow"><span class="status-light"></span> LOCAL EXPLORATION / 04</p>
        <h2>world_exection<span class="cursor" aria-hidden="true">_</span></h2>
        <p class="subtitle">小型交互原型 <span aria-hidden="true">/</span> 离开页面后重置</p>
      </div>
      <button class="reset" data-terminal-action="reset" @click="reset">重置会话 <span>RESET</span></button>
    </header>

    <div class="terminal-layout">
      <div class="workspace">
        <div class="graph-heading"><span>信号拓扑</span><span>{{ connected ? 'LINK ACTIVE' : 'LOCAL ONLY' }}</span></div>
        <div class="graph" :data-terminal-mode="mode" aria-label="信号路径图">
          <div class="graph-glow" aria-hidden="true"></div>
          <div class="coordinates" aria-hidden="true">NET / 00:04<br>SESSION SANDBOX</div>
          <svg class="edges" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
            <path v-for="edge in edges" :key="edge.id + '-base'" :d="edge.d" class="edge-base" />
            <path v-for="edge in edges" :key="edge.id" :d="edge.d" :data-terminal-edge="edge.id" class="edge-flow" />
          </svg>
          <div class="node-anchor local">
            <button class="node" data-terminal-node="local" :aria-pressed="selected === 'local'" @click="selected = 'local'">
              <span class="node-symbol" aria-hidden="true">&gt;_</span><strong>本地终端</strong><span class="node-caption">LOCAL / 01</span>
            </button>
          </div>
          <div v-if="scanned" class="node-anchor signal">
            <button class="node" data-terminal-node="signal" :aria-pressed="selected === 'signal'" @click="selected = 'signal'">
              <span class="node-symbol" aria-hidden="true">[ ? ]</span><strong>未知信号</strong><span class="node-caption">SIGNAL / 02</span>
            </button>
          </div>
          <div v-if="discovered" class="node-anchor relay">
            <button class="node" data-terminal-node="relay" :disabled="!connected" :aria-pressed="selected === 'relay'" @click="selected = 'relay'">
              <span class="node-symbol" aria-hidden="true">[ : ]</span><strong>隔离中继</strong><span class="node-caption">RELAY / 03</span>
            </button>
          </div>
          <div v-if="discovered" class="node-anchor archive">
            <button class="node" data-terminal-node="archive" :disabled="!connected" :aria-pressed="selected === 'archive'" @click="selected = 'archive'">
              <span class="node-symbol" aria-hidden="true">[ ≡ ]</span><strong>封存档案</strong><span class="node-caption">ARCHIVE / 04</span>
            </button>
          </div>
          <p class="graph-note">{{ !scanned ? '等待扫描 · 从本地开始' : !connected ? '离线 · 可连接未知信号' : route === 'relay' ? '隔离路径 / SIGNAL → RELAY → ARCHIVE' : '直连路径 / SIGNAL → ARCHIVE' }}</p>
        </div>

        <div class="controls">
          <div class="selection"><span>当前目标</span><strong>{{ labels[selected] }}</strong><span class="selection-code">SELECT / INSPECT</span></div>
          <div class="action-row">
            <button data-terminal-action="scan" :disabled="scanned" @click="scan">扫描信号 <span>SCAN</span></button>
            <button data-terminal-action="inspect" :disabled="!canInspect" @click="inspect">检查目标 <span>INSPECT</span></button>
            <button data-terminal-action="connect" :disabled="!scanned || connected" @click="connect">{{ discovered ? '重新连接' : '建立连接' }} <span>CONNECT</span></button>
            <button data-terminal-action="disconnect" :disabled="!connected" @click="disconnect">断开连接 <span>DISCONNECT</span></button>
          </div>
          <div v-if="discovered" class="route-controls">
            <span class="route-label">改接路径</span>
            <div class="action-row">
              <button data-terminal-action="route-direct" :disabled="!connected || route === 'direct'" :aria-pressed="connected && route === 'direct'" @click="rewire('direct')">直接连接 <span>DIRECT</span></button>
              <button data-terminal-action="route-relay" :disabled="!connected || route === 'relay'" :aria-pressed="connected && route === 'relay'" @click="rewire('relay')">经由中继 <span>VIA RELAY</span></button>
              <button class="read-action" data-terminal-action="read" :disabled="!connected" @click="readArchive">读取档案 <span>READ</span></button>
            </div>
          </div>
          <p class="feedback">{{ message }}</p>
        </div>
      </div>

      <aside class="side-panel" aria-label="会话状态与本地记录">
        <section class="status-section">
          <h3>会话状态 <span>STATUS</span></h3>
          <dl>
            <div><dt>连接</dt><dd :class="{ online: connected }">{{ connected ? '已连接' : '已断开' }}</dd></div>
            <div><dt>路由</dt><dd>{{ !connected ? '无活动路径' : route === 'relay' ? '隔离中继' : '直接连接' }}</dd></div>
            <div><dt>档案访问</dt><dd>{{ !connected ? '关闭' : route === 'relay' ? '允许读取' : '来源受限' }}</dd></div>
            <div><dt>发现目标</dt><dd>{{ discovered ? '04' : scanned ? '02' : '01' }} / 04</dd></div>
          </dl>
        </section>
        <section v-if="fragment" class="fragment" aria-label="已读档案片段">
          <h3>片段 01 <span>LOCAL COPY</span></h3>
          <p>“入口没有消失，只是不再接受直接抵达。”</p>
          <small>已读片段 · 断开连接后仍保留</small>
        </section>
        <section class="log-section">
          <h3>本地记录 <span>LAST 08</span></h3>
          <ol class="log" aria-live="polite" aria-relevant="additions" aria-label="按时间顺序排列的最近八条本地记录">
            <li v-for="entry in records" :key="entry.id"><span class="log-index">{{ String(entry.id).padStart(2, '0') }}</span><span>{{ entry.text }}</span></li>
          </ol>
        </section>
        <p class="session-note">仅本地交互 · 无存档 · 无外部连接</p>
      </aside>
    </div>
  </section>
</template>

<style scoped>
.terminal { --ink: #d9e8ed; --muted: #81969f; --accent: #91e5ce; --border: #283c47; color: var(--ink); background: #0c141c; border: 1px solid var(--border); border-radius: 18px; overflow: hidden; font-family: ui-monospace, SFMono-Regular, Consolas, 'Liberation Mono', monospace; text-align: left; box-shadow: 0 18px 70px #0003; }
.terminal * { box-sizing: border-box; }
.terminal-header { padding: 28px 30px 24px; display: flex; align-items: center; justify-content: space-between; gap: 16px; border-bottom: 1px solid var(--border); }
.eyebrow { margin: 0 0 10px; color: var(--accent); font-size: 10px; letter-spacing: 1.8px; display: flex; align-items: center; gap: 8px; }
.status-light { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); box-shadow: 0 0 12px #91e5ce55; }
h2 { margin: 0; font-size: clamp(21px, 3.5vw, 30px); font-weight: 500; letter-spacing: -1px; }
.cursor { color: var(--accent); }
.subtitle { margin: 10px 0 0; font-size: 11px; color: var(--muted); }
.subtitle span { padding: 0 7px; color: #46606c; }
.terminal button { font: inherit; color: var(--ink); border: 1px solid #344b57; background: #15222c; cursor: pointer; transition: border-color .18s, background .18s; }
.terminal button:hover:not(:disabled) { background: #203840; border-color: var(--accent); }
.terminal button:focus-visible { outline: 2px solid #c4fff0; outline-offset: 4px; }
.terminal button:disabled { opacity: .4; cursor: not-allowed; }
.terminal button span:not(.node-symbol):not(.node-caption) { font-size: 9px; color: var(--muted); letter-spacing: .5px; }
.terminal .reset { padding: 10px 12px; border-radius: 6px; font-size: 11px; flex-shrink: 0; }
.reset span { margin-left: 8px; }
.terminal-layout { display: grid; grid-template-columns: minmax(0, 1fr) 245px; }
.workspace { min-width: 0; }
.graph-heading { display: flex; justify-content: space-between; padding: 18px 22px 0; font-size: 11px; }
.graph-heading span:last-child { font-size: 9px; color: var(--muted); letter-spacing: 1px; }
.graph { isolation: isolate; position: relative; min-height: 290px; aspect-ratio: 1.8; overflow: hidden; background-image: radial-gradient(#53687933 1px, transparent 1px); background-size: 20px 20px; }
.graph-glow { position: absolute; inset: -25%; z-index: -1; background: radial-gradient(ellipse at 45% 40%, #297d7522, transparent 50%); animation: atmosphere 14s ease-in-out infinite alternate; pointer-events: none; }
.coordinates { position: absolute; top: 22px; left: 22px; color: #5d7380; font-size: 8px; line-height: 1.8; letter-spacing: 1px; }
.edges { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; overflow: visible; }
.edges path { fill: none; vector-effect: non-scaling-stroke; }
.edge-base { stroke: #38545d; stroke-width: 1; }
.edge-flow { stroke: #91e5ce; stroke-width: 1.5; stroke-dasharray: 4 9; animation: flow 3s linear infinite; opacity: .75; }
.node-anchor { position: absolute; transform: translate(-50%, -50%); width: 98px; }
.local { left: 17%; top: 53%; }
.signal { left: 43%; top: 53%; }
.relay { left: 64%; top: 23%; }
.archive { left: 82%; top: 53%; }
.terminal .node { width: 100%; min-height: 91px; padding: 10px 4px; border-radius: 10px; display: flex; flex-direction: column; align-items: center; gap: 7px; background: #101e28; box-shadow: 0 8px 22px #0003; animation: float 5s ease-in-out infinite; }
.signal .node { animation-delay: -.9s; }
.relay .node { animation-delay: -2s; }
.archive .node { animation-delay: -3s; }
.terminal .node:hover, .terminal .node:focus, .terminal .node:disabled { animation-play-state: paused; }
.terminal .node[aria-pressed="true"] { border-color: var(--accent); background: #18302f; }
.node-symbol { font-size: 19px; color: var(--accent); line-height: 1; }
.node strong { font-size: 11px; font-weight: 500; }
.node-caption { font-size: 8px; letter-spacing: .3px; color: var(--muted); }
.graph-note { position: absolute; bottom: 14px; left: 12px; right: 12px; text-align: center; font-size: 9px; color: var(--muted); letter-spacing: .4px; margin: 0; }
.controls { border-top: 1px solid var(--border); padding: 19px 22px 22px; background: #0e1922; }
.selection { display: flex; align-items: center; gap: 10px; font-size: 10px; color: var(--muted); margin-bottom: 14px; }
.selection strong { color: var(--ink); font-weight: 500; }
.selection-code { margin-left: auto; font-size: 8px; letter-spacing: .5px; }
.action-row { display: flex; flex-wrap: wrap; gap: 8px; }
.action-row button { display: flex; flex-direction: column; align-items: flex-start; gap: 5px; padding: 10px 12px; min-height: 48px; border-radius: 6px; font-size: 11px; flex: 1 1 92px; }
.route-controls { margin-top: 17px; }
.route-label { display: block; font-size: 10px; color: var(--muted); margin-bottom: 8px; }
.terminal .read-action { border-color: #487769; }
.action-row button[aria-pressed="true"] { opacity: .8; border-color: #5caa95; }
.feedback { margin: 16px 0 0; border-left: 2px solid #5caa95; padding-left: 10px; color: #b6ccc9; font-size: 11px; line-height: 1.8; min-height: 40px; }
.side-panel { border-left: 1px solid var(--border); padding: 22px 19px; background: #101a23; min-width: 0; }
h3 { margin: 0 0 17px; display: flex; justify-content: space-between; align-items: center; font-size: 11px; font-weight: 500; }
h3 span { color: var(--muted); font-size: 8px; letter-spacing: 1px; }
dl { margin: 0; }
dl div { display: flex; justify-content: space-between; gap: 8px; margin: 13px 0; font-size: 10px; }
dt { color: var(--muted); }
dd { margin: 0; }
.online { color: var(--accent); }
.log-section { border-top: 1px solid var(--border); padding-top: 20px; margin-top: 22px; }
.log { padding: 0; margin: 0; list-style: none; }
.log li { display: flex; gap: 10px; color: #a6bac5; font-size: 10px; line-height: 1.8; padding: 0 0 13px; overflow-wrap: anywhere; }
.log-index { color: #587582; font-size: 9px; padding-top: 1px; flex-shrink: 0; }
.fragment { margin-top: 22px; padding: 14px 12px; border: 1px solid #33584f; border-radius: 7px; background: #142722; }
.fragment h3 { color: var(--accent); margin-bottom: 10px; }
.fragment p { margin: 0 0 10px; font-size: 12px; line-height: 1.9; }
.fragment small, .session-note { font-size: 9px; color: var(--muted); line-height: 1.8; }
.session-note { margin: 15px 0 0; }
@keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
@keyframes flow { to { stroke-dashoffset: -52; } }
@keyframes atmosphere { from { transform: translate(-4%, -2%); opacity: .6; } to { transform: translate(5%, 4%); opacity: 1; } }
@media (max-width: 760px) {
  .terminal-layout { grid-template-columns: minmax(0, 1fr); }
  .side-panel { border-left: 0; border-top: 1px solid var(--border); display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.4fr); gap: 20px; }
  .log-section { border-top: 0; padding-top: 0; margin-top: 0; grid-column: 2; grid-row: 1 / span 3; }
  .fragment { margin: 0; }
  .session-note { margin: 0; }
}
@media (max-width: 480px) {
  .terminal-header { padding: 20px 16px; flex-wrap: wrap; }
  .terminal .reset { padding: 9px 10px; }
  .graph { aspect-ratio: 1.1; min-height: 290px; }
  .node-anchor { width: 72px; }
  .terminal .node { min-height: 82px; padding: 10px 2px; }
  .node strong { font-size: 10px; }
  .node-caption { font-size: 7px; letter-spacing: -.3px; }
  .controls { padding: 16px; }
  .selection-code { display: none; }
  .side-panel { display: block; padding: 20px 16px; }
  .log-section { border-top: 1px solid var(--border); margin-top: 20px; padding-top: 20px; }
  .fragment { margin-top: 20px; }
  .graph-note { font-size: 8px; }
}
@media (prefers-reduced-motion: reduce) {
  .terminal *, .terminal *::before, .terminal *::after { animation: none !important; transition: none !important; }
}
</style>
