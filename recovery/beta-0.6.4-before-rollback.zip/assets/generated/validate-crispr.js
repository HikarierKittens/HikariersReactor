// GENERATED from src/state/validate-crispr.ts — do not edit.

/** Permanent unlocks do not require the current run to have researched CRISPR. */
function validateCrispr(raw, state) {
    const value = raw.crispr;
    if (value === undefined) {
        state.crispr = [];
        return;
    }
    if (!Array.isArray(value) || value.some(id => typeof id !== 'string' || !Object.hasOwn(CRISPR_UPGRADES, id)) || new Set(value).size !== value.length)
        throw Error('CRISPR升级记录无效。');
    const upgrades = value;
    if (upgrades.some(id => !CRISPR_UPGRADES[id].pre.every(pre => upgrades.includes(pre))))
        throw Error('CRISPR升级前置缺失。');
    state.crispr = [...upgrades];
}
