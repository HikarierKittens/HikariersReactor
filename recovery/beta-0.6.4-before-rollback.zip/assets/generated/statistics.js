// GENERATED from src/simulation/statistics.ts — do not edit.
function createStatistics() {
    return {
        lifetime: { knowledgeSpent: 0, starved: 0, soldierDeaths: 0, days: 0, particlesEarned: 0, casimirEarned: 0, darkEnergyEarned: 0 },
        run: { knowledgeSpent: 0, starved: 0, soldierDeaths: 0, days: 0 },
    };
}
/** Old partial simulation fixtures are supported without inventing past events. */
function ensureStatistics(state) {
    const defaults = createStatistics();
    const current = state.statistics;
    for (const scope of ['lifetime', 'run']) {
        for (const key of Object.keys(defaults[scope])) {
            const value = current?.[scope]?.[key];
            if (typeof value === 'number' && Number.isFinite(value) && value >= 0) {
                defaults[scope][key] = Math.min(Number.MAX_SAFE_INTEGER, value);
            }
        }
    }
    state.statistics = defaults;
    return defaults;
}
function record(state, key, amount) {
    if (!Number.isFinite(amount) || amount <= 0)
        return;
    const stats = ensureStatistics(state);
    stats.lifetime[key] = Math.min(Number.MAX_SAFE_INTEGER, stats.lifetime[key] + amount);
    stats.run[key] = Math.min(Number.MAX_SAFE_INTEGER, stats.run[key] + amount);
}
function recordKnowledgeSpent(state, amount) { record(state, 'knowledgeSpent', amount); }
function recordStarvation(state, count) { record(state, 'starved', count); }
function recordSoldierDeaths(state, count) { record(state, 'soldierDeaths', count); }
function recordGameDays(state, days) { record(state, 'days', days); }
function recordCasimirEarned(state, amount) {
    if (!Number.isFinite(amount) || amount <= 0)
        return;
    const stats = ensureStatistics(state);
    stats.lifetime.casimirEarned = Math.min(Number.MAX_SAFE_INTEGER, stats.lifetime.casimirEarned + amount);
}
function recordDarkEnergyEarned(state, amount) {
    if (!Number.isFinite(amount) || amount <= 0)
        return;
    const stats = ensureStatistics(state);
    stats.lifetime.darkEnergyEarned = Math.min(Number.MAX_SAFE_INTEGER, stats.lifetime.darkEnergyEarned + amount);
}
function recordParticlesEarned(state, amount) {
    if (!Number.isFinite(amount) || amount <= 0)
        return;
    const stats = ensureStatistics(state);
    stats.lifetime.particlesEarned = Math.min(Number.MAX_SAFE_INTEGER, stats.lifetime.particlesEarned + amount);
}
