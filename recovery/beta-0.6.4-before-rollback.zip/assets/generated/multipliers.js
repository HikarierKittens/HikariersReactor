// GENERATED from src/simulation/multipliers.ts — do not edit.






/** Legacy hook kept for save compatibility: communityCenter no longer boosts production. */
function calculateCommunityMultiplier(id, state) {
    return 1;
}
function calculateKnowledgeMultiplier(state, dataUnits) {
    return 1 + Object.keys(BUILDINGS).reduce((sum, id) => sum + (id === 'observatory' ? dataUnits : state.buildings[id] || 0) * (BUILDINGS[id].knowledgeBoost || 0), 0);
}
function calculateAluminumMultiplier(state) { return calculateRefiningMultiplier('aluminum', state); }
/** Particle imbalance repurposes accelerators for ordinary production, including knowledge. */
function calculateChallengeAcceleratorMultiplier(id, state) {
    return isChallengeGeneActive(state, 'particleImbalance') && Object.hasOwn(RESOURCES, id)
        && id !== 'energy'
        ? 1 + (RESOURCES[id].crafted ? .0125 : .05) * (state.buildings.particleAccelerator || 0) : 1;
}
function calculateProductionMultiplier(id, happiness, state) {
    return happiness / 100 * calculateCommunityMultiplier(id, state) * calculateRefiningMultiplier(id, state)
        * (id === 'cash' ? 1 : calculateGovernmentMultiplier(id, state)) * calculateChallengeAcceleratorMultiplier(id, state);
}
function calculateFactoryOutputMultiplier(id, happiness, state, knowledge) {
    return (RESOURCES[id].crafted || id === 'energy' ? 1 : calculateProductionMultiplier(id, happiness, state) * (id === 'knowledge' ? knowledge : 1))
        * calculateParticleMultiplier(id, state) * (RESOURCES[id].crafted ? calculateChallengeAcceleratorMultiplier(id, state) : 1) * (state.government === 'industrialism' ? 1.25 : 1)
        * (id === 'polymer' && state.tech.includes('titaniumAlloyReactor') ? 1.5 : 1);
}
