// GENERATED from src/simulation/quantum.ts — do not edit.



/** Completed cores are indivisible; partial segments never reserve fuel or grant quantum. */
function settleQuantumCores(state, pool, dt = 1) {
    const cores = Math.min(countRunningBuildings('aiSupercore', state), Math.floor((Math.max(0, pool.helium3) + 1e-8) / (25 * dt)), Math.floor((Math.max(0, pool.energy) + 1e-8) / (100 * dt)));
    pool.helium3 = Math.max(0, pool.helium3 - cores * 25 * dt);
    pool.energy = Math.max(0, pool.energy - cores * 100 * dt);
    return cores;
}
/** Inject the already-funded storage snapshot during settlement to avoid preview recursion. */
function calculateQuantumSnapshot(state, snapshot, fundedCores, dt = 1) {
    if (!snapshot) {
        // Explicit baseline power breaks quantum -> support -> power -> quantum recursion.
        // Core fuel is reserved first, so extra swarm power cannot displace cores.
        // Iterate monotonically from baseline as additional power enables storage.
        let level = 0;
        let result;
        for (let pass = 0; pass < 16; pass++) {
            const support = calculateSupportPreview(state, dt, level);
            result = calculateQuantumSnapshot(state, { ...support, moonBaseUnits: support.moon.baseUnits }, support.aiSupercoreUnits);
            if (result.level === level)
                break;
            level = result.level;
        }
        return result;
    }
    const knowledgeCapacity = calculateStorageDetails('knowledge', state, snapshot).total;
    const base = state.tech.includes('artificialIntelligenceII') ? knowledgeCapacity / 100000 : 0;
    const cores = fundedCores ?? 0;
    const level = Math.floor(base * (1 + .25 * cores) * 100) / 100;
    return { knowledgeCapacity, base, cores, level };
}
function calculateQuantumLevel(state, dt = 1) { return calculateQuantumSnapshot(state, undefined, undefined, dt).level; }
function calculateSwarmSupportCapacity(state, quantumLevel) {
    return countRunningBuildings('swarmControlStation', state) * (20 + (state.tech.includes('quantumSwarm') ? quantumLevel ?? calculateQuantumLevel(state) : 0));
}
function calculateQuantumManufacturingMultiplier(state, quantumLevel) {
    return state.tech.includes('quantumManufacturing') ? 1 + .1 * quantumLevel : 1;
}
