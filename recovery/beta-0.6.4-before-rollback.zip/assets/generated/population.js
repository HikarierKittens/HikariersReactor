// GENERATED from src/simulation/population.ts — do not edit.





/** Jobs share civilian population; the existing independent army is left untouched. */
function reconcilePopulationAssignments(state) {
    let spare = state.population;
    for (const id of Object.keys(state.workers)) {
        state.workers[id] = Math.min(state.workers[id], spare);
        spare -= state.workers[id];
    }
    trimAssignedCraftWorkers(state);
}
/** Count only the part of this step spent without food, never time spent eating reserves. */
function advanceStarvation(state, dt, foodRate, foodBefore = 0) {
    if (state.resources.food > 0 || foodRate >= 0 || state.population <= 0) {
        state.starvationElapsed = 0;
        return;
    }
    if (foodBefore > 0)
        state.starvationElapsed = 0;
    const hungrySeconds = Math.max(0, dt - foodBefore / -foodRate);
    state.starvationElapsed += hungrySeconds;
    const deaths = Math.min(state.population, Math.floor((state.starvationElapsed + 1e-9) / 10));
    if (!deaths)
        return;
    state.starvationElapsed = Math.max(0, state.starvationElapsed - deaths * 10);
    state.population -= deaths;
    recordStarvation(state, deaths);
    reconcilePopulationAssignments(state);
    for (let i = 0; i < deaths; i++)
        addLog(state, '一只猫猫饿死了.....', 'event');
    if (state.population === 0)
        state.starvationElapsed = 0;
}
function sampleGrowthTarget(state, random = Math.random) {
    return state.population < 20
        ? CONFIG.growthFastMin + random() * (CONFIG.growthFastMax - CONFIG.growthFastMin)
        : CONFIG.growthMin + random() * (CONFIG.growthMax - CONFIG.growthMin);
}
function averageGrowthTarget(state) {
    return state.population < 20 ? (CONFIG.growthFastMin + CONFIG.growthFastMax) / 2 : (CONFIG.growthMin + CONFIG.growthMax) / 2;
}
function calculateFoodPerCat(state) {
    return CONFIG.foodPerCat * (state.buildings.communityCenter ? .9 : 1);
}
function calculateGrowthMultiplier(state) {
    return (state.tech.includes('scientificBreeding') ? 1.25 : 1) * (state.crispr?.includes('coreReplication') ? 1.15 : 1)
        * (state.buildings.communityCenter ? 1.1 : 1) * (1 + geneBonus(state, 'maturationAcceleration'));
}
/** Cats above the current housing capacity leave immediately; the independent army is untouched. */
function enforcePopulationCapacity(state, capacity) {
    const limit = Math.max(0, Math.floor(capacity + 1e-9));
    const lost = Math.max(0, state.population - limit);
    if (!lost)
        return 0;
    state.population -= lost;
    state.growth = 0;
    state.growthTarget = 0;
    reconcilePopulationAssignments(state);
    addLog(state, `猫口超出住房上限，${lost}只猫猫离开了文明。`, 'event');
    return lost;
}
/** Preserve one arrival per simulation step, even when the supplied step is large. */
function advancePopulationGrowth(state, dt, foodRate, capacity, random = Math.random) {
    if (foodRate >= -1e-8 && state.resources.food > 0 && state.population < capacity) {
        state.growth += dt * calculateGrowthMultiplier(state);
        if (!state.growthTarget)
            state.growthTarget = sampleGrowthTarget(state, random);
        if (state.growth >= state.growthTarget) {
            state.growth -= state.growthTarget;
            state.growthTarget = 0;
            state.population++;
        }
    }
    else {
        state.growth = 0;
        state.growthTarget = 0;
    }
}
