// GENERATED from src/simulation/factory.ts — do not edit.



function scaleRecipe(recipe, scale) {
    return Object.fromEntries(Object.entries(recipe).map(([id, amount]) => [
        id, Number((amount * scale).toPrecision(12)),
    ]));
}
/** Unknown line IDs retain the previous safe empty-recipe behavior. */
function calculateFactoryRecipe(id, state) {
    const option = FACTORY_OPTIONS.find(candidate => candidate.id === id);
    if (!option)
        return { input: {}, output: {} };
    const speed = 1 + (state.tech.includes('automatedEngineering') ? .3 : 0)
        + (state.tech.includes('intelligentFactory') ? .5 : 0);
    const chemical = state.tech.includes('chemicalDeposition') ? 1.2 : 1;
    // 完美主义 raises base line output only; ingredient demand is unchanged.
    const perfectionism = 1 + geneBonus(state, 'perfectionism');
    return { input: scaleRecipe(option.input, speed), output: scaleRecipe(option.output, speed * chemical * perfectionism * (id === 'alloy' && state.tech.includes('quantumTunnelingThermalProcessing') ? 1.1 : 1)) };
}
function calculateFactoryCapacity(state) {
    return Object.keys(BUILDINGS).reduce((sum, id) => sum + (BUILDINGS[id].lines || 0) * Math.max(0, (state.buildings[id] || 0) - (state.stoppedBuildings?.[id] || 0)), 0);
}
/** Retract excess assignments from the largest line categories first; ties use registry order. */
function trimFactoryAssignments(state) {
    let excess = Math.max(0, countAssignedLines(state) - calculateFactoryCapacity(state));
    const removed = excess;
    const options = [...FACTORY_OPTIONS].sort((a, b) => state.lines[b.id] - state.lines[a.id]);
    for (const option of options) {
        if (!excess)
            break;
        const amount = Math.min(excess, state.lines[option.id]);
        state.lines[option.id] -= amount;
        excess -= amount;
    }
    return removed;
}
function countAssignedLines(state) {
    return Object.values(state.lines || {}).reduce((sum, count) => sum + count, 0);
}
/** Owned 冶炼厂工位 (冶炼厂 +1, 恒星熔炉 +2), ignoring stopped smelters; bounds the idle setting. */
function calculateSmelterSlotCapacity(state) {
    return (state.buildings.smelter || 0) + 2 * (state.buildings.stellarForge || 0);
}
/** 冶炼厂工位 assigned to 钢冶炼: every non-idle slot, so new slots auto-run steel. */
function countSteelSmelterSlots(state) {
    return Math.max(0, calculateSmelterSlotCapacity(state) - Math.min(state.smelterIdle || 0, calculateSmelterSlotCapacity(state)));
}
/** Steel slots that actually run: stopped smelters remove their own slot first. */
function calculateRunningSmelterSlots(state) {
    const running = Math.max(0, (state.buildings.smelter || 0) - (state.stoppedBuildings?.smelter || 0)) + 2 * (state.buildings.stellarForge || 0);
    return Math.max(0, running - Math.min(state.smelterIdle || 0, calculateSmelterSlotCapacity(state)));
}
