// GENERATED from src/simulation/stage-four.ts — do not edit.
/** The empty fourth world subpage retains its original main-world prerequisites. */
function isStageFourEntranceUnlocked(state) {
    return state.tech.includes('artificialIntelligenceII')
        && state.tech.includes('overclocking13')
        && state.tech.includes('penroseTheory')
        && state.stageThree.coreActivated
        && state.buildings.massEjector >= 1;
}
