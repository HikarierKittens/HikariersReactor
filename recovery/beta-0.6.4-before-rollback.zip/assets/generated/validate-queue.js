// GENERATED from src/state/validate-queue.ts — do not edit.








/** Reconstruct only whitelisted fields from untrusted queue entries. */
function validateSaveQueue(value, state) {
    const pending = value === undefined ? [] : value;
    if (!Array.isArray(pending) || pending.length > 10000)
        throw Error('待购队列无效。');
    const seenUID = new Set(), seenTech = new Set();
    const buildCounts = {};
    const seenMissions = new Set();
    const seenShip = new Set();
    const validated = pending.map((entry) => {
        if (!entry || typeof entry !== 'object')
            throw Error('队列项目无效。');
        const q = entry;
        if ((q.kind !== 'build' && q.kind !== 'tech' && q.kind !== 'arpa' && q.kind !== 'mission' && q.kind !== 'ship') || typeof q.id !== 'string' || typeof q.uid !== 'number' || !Number.isSafeInteger(q.uid) || q.uid < 1 || seenUID.has(q.uid))
            throw Error('队列项目无效。');
        seenUID.add(q.uid);
        if (Object.hasOwn(q, 'segments') && (q.kind !== 'build' || !BUILDINGS[q.id]?.segmentedRequired
            || typeof q.segments !== 'number' || !Number.isSafeInteger(q.segments) || q.segments < 1
            || q.segments > BUILDINGS[q.id].segmentedRequired))
            throw Error('分段队列数量无效。');
        if (q.kind === 'ship') {
            const id = q.id;
            if (!isShipComponentId(id) || !isShipComponentUnlocked(id, state) || state.shipComponents?.[id] || seenShip.has(id))
                throw Error('飞船组件队列无效。');
            seenShip.add(id);
            return { uid: q.uid, kind: 'ship', id };
        }
        if (q.kind === 'mission') {
            const id = q.id;
            if (!isRegionalMissionId(id) || !isRegionalMissionAvailable(state, id) || isRegionalMissionCompleted(state, id) || seenMissions.has(id))
                throw Error('队列任务无效。');
            seenMissions.add(id);
            return { uid: q.uid, kind: 'mission', id };
        }
        if (q.kind === 'tech') {
            const id = q.id;
            if (!Object.hasOwn(TECHNOLOGIES, id) || state.tech.includes(id) || seenTech.has(id) || !isTechnologyUnlocked(id, state))
                throw Error('队列科技无效。');
            seenTech.add(id);
            return { uid: q.uid, kind: 'tech', id };
        }
        if (q.kind === 'arpa') {
            if (!isProjectUnlocked(q.id, state))
                throw Error('工程队列无效');
            return { uid: q.uid, kind: 'arpa', id: q.id };
        }
        const id = q.id;
        if (!Object.hasOwn(BUILDINGS, id) || !isBuildingUnlocked(id, state))
            throw Error('队列建筑无效。');
        buildCounts[id] = (buildCounts[id] || 0) + (q.segments ?? 1);
        if (state.buildings[id] + buildCounts[id] > (BUILDINGS[id].segmentedRequired ?? BUILDINGS[id].max ?? Infinity))
            throw Error('队列超过建筑上限。');
        return { uid: q.uid, kind: 'build', id, ...(Object.hasOwn(q, 'segments') ? { segments: q.segments } : {}) };
    });
    // Historical queues stored each segment as an entry. Merge adjacent legacy runs
    // into one project (up to the old 100-segment slot), retaining their first uid.
    const projects = [];
    let legacyRun = false;
    for (const item of validated) {
        const legacy = item.kind === 'build' && !!BUILDINGS[item.id].segmentedRequired && item.segments === undefined;
        const previous = projects.at(-1);
        if (legacy && legacyRun && previous?.kind === 'build' && item.kind === 'build'
            && previous.id === item.id && (previous.segments ?? 1) < 100) {
            previous.segments = (previous.segments ?? 1) + 1;
        }
        else {
            projects.push(legacy && item.kind === 'build' ? { ...item, segments: 1 } : item);
        }
        legacyRun = legacy;
    }
    const buildingLaneCount = buildingQueueUsage(projects);
    if (buildingLaneCount + projects.filter(item => item.kind === 'tech').length > 100)
        throw Error('待购队列无效。');
    // Existing build-only queues retain their historical capacity grandfathering.
    if (projects.some(item => item.kind === 'mission' || item.kind === 'ship')
        && buildingLaneCount > purchaseQueueCapacity(state, 'build'))
        throw Error('队列超过建筑队列容量。');
    return projects;
}
