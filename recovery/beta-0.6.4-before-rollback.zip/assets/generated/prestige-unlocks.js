// GENERATED from src/simulation/prestige-unlocks.ts — do not edit.
const PRESTIGE_RESOURCE_IDS = ['particles', 'casimir', 'darkEnergy'];
/** Displayed once ever held: the sticky record, or a currently positive amount. */
function isPrestigeResourceUnlocked(state, id) {
    return (state.prestigeUnlocked?.includes(id) ?? false) || (state.prestige[id] || 0) > 0;
}
/** Record every currently held prestige resource; never removes an entry. */
function syncPrestigeUnlocks(state) {
    for (const id of PRESTIGE_RESOURCE_IDS) {
        if ((state.prestige[id] || 0) > 0 && !state.prestigeUnlocked.includes(id))
            state.prestigeUnlocked.push(id);
    }
}
