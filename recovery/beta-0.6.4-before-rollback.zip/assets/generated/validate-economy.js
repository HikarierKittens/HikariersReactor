// GENERATED from src/state/validate-economy.ts — do not edit.







// The generated legacy bridge strips imports; re-exported helpers would be undefined there.
// Keep the local wrappers so the inlined const arrays satisfy the generated VM suites.
void isOptionalBuildingKey;
void isDefaultZeroResource;
/** Optional lookup retains legacy missing-field behavior without trusting JSON values. */
function savedField(record, key) {
    return record == null ? undefined : record[key];
}
function validateFactoryAssignments(raw, state) {
    for (const option of FACTORY_OPTIONS) {
        const saved = savedField(raw, option.id);
        const count = validateSaveNumber(saved === undefined ? 0 : saved, 0, Number.MAX_SAFE_INTEGER, '生产线分配');
        state.lines[option.id] = count;
        if (!Number.isInteger(count) || (count > 0 && !isFactoryLineUnlocked(option.id, state)))
            throw Error('生产线分配无效。');
    }
    if (countAssignedLines(state) > calculateFactoryCapacity(state))
        throw Error('生产线分配超过工厂数量。');
}
/** Older saves lack smelterIdle: every 冶炼厂工位 defaults to 钢冶炼. */
function validateSmelterAssignments(raw, state) {
    const idle = validateSaveNumber(raw === undefined ? 0 : raw, 0, calculateSmelterSlotCapacity(state), '冶炼厂工位');
    if (!Number.isInteger(idle))
        throw Error('冶炼厂工位无效。');
    state.smelterIdle = idle;
}
function validateEconomyRecords(raw, state) {
    for (const id of Object.keys(RESOURCES)) {
        const saved = savedField(raw.resources, id);
        state.resources[id] = validateSaveNumber(isDefaultZeroResource(id) && saved === undefined ? 0 : saved, 0, 1e100, '资源');
    }
    for (const id of Object.keys(BUILDINGS)) {
        const building = BUILDINGS[id];
        // Infinity is a comparison bound only; saved counts must remain finite safe integers.
        // Only explicitly additive keys may be absent; malformed present values are rejected.
        const saved = savedField(raw.buildings, id);
        state.buildings[id] = validateSaveNumber(isOptionalBuildingKey(id) && saved === undefined ? 0 : saved, 0, building.max ?? Infinity, '建筑');
    }
    for (const id of Object.keys(BUILDINGS)) {
        const building = BUILDINGS[id];
        const workerCap = id === 'catCafe' ? state.buildings.catCafe * (building.artistSlots || 0) : calculateWorkerCapacity(id, state);
        const saved = savedField(raw.workers, id);
        state.workers[id] = validateSaveNumber(isOptionalBuildingKey(id) && saved === undefined ? 0 : saved, 0, workerCap, '工作分配');
        if (!Number.isSafeInteger(state.buildings[id]) || !Number.isSafeInteger(state.workers[id]) || (!building.output && !building.workerOutput && !building.artistSlots && !building.craftSlots && state.workers[id]))
            throw Error('建筑或工作分配无效。');
    }
    // Merge the former cafe-specific assignments into the shared artist job.
    const artists = state.workers.theater + state.workers.catCafe;
    if (!Number.isSafeInteger(artists) || artists > calculateWorkerCapacity('theater', state))
        throw Error('艺术家分配超额。');
    state.workers.theater = artists;
    state.workers.catCafe = 0;
    // Planetary foundries extend the existing shared artisan assignment, not a second job.
    const artisans = state.workers.foundry + state.workers.planetaryFoundry;
    if (!Number.isSafeInteger(artisans) || artisans > calculateWorkerCapacity('foundry', state))
        throw Error('工匠分配超额。');
    state.workers.foundry = artisans;
    state.workers.planetaryFoundry = 0;
    for (const id of Object.keys(CRAFT_RECIPES)) {
        const saved = savedField(raw.craftWorkers, id);
        state.craftWorkers[id] = validateSaveNumber(id === 'aerogel' && saved === undefined ? 0 : saved, 0, state.workers.foundry, '工匠分配');
        if (!Number.isInteger(state.craftWorkers[id]))
            throw Error('工匠分配无效。');
    }
    if (Object.values(state.craftWorkers).reduce((sum, count) => sum + count, 0) > state.workers.foundry)
        throw Error('工匠分配超额。');
}
