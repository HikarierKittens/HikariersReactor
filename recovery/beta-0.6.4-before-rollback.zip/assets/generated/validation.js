// GENERATED from src/state/validation.ts — do not edit.




function validateStorageAssignments(raw, state) {
    const stopped = raw.stoppedBuildings;
    for (const id of ['catCafe', 'touristCenter'])
        if (stopped?.[id] !== undefined && !Number.isInteger(stopped[id]))
            throw Error('商业设施停用数量无效');
    for (const id of Object.keys(BUILDINGS)) {
        const saved = stopped?.[id];
        const newBuilding = NEW_BUILDING_STOPPED.includes(id);
        const ownedUnits = Math.floor(state.buildings[id] / (BUILDINGS[id].segmentedRequired || 1));
        state.stoppedBuildings[id] = Math.min(ownedUnits, validateSaveNumber(newBuilding ? (saved === undefined ? 0 : saved) : saved ?? 0, 0, ownedUnits, '停用建筑'));
        if (!Number.isSafeInteger(state.stoppedBuildings[id]))
            throw Error('停用建筑数据无效。');
    }
    for (const id of Object.keys(BUILDINGS))
        if (BUILDINGS[id].alwaysRunning)
            state.stoppedBuildings[id] = 0;
    state.containers = validateSaveNumber(raw.containers, 0, calculateContainerCapacity(state), '集装箱');
    if (!Number.isSafeInteger(state.containers))
        throw Error('集装箱数量无效。');
    const assignments = raw.containerAssignments;
    if (!assignments || typeof assignments !== 'object' || Object.keys(assignments).some(id => !Object.hasOwn(RESOURCES, id)))
        throw Error('集装箱分配无效。');
    const values = assignments;
    for (const id of Object.keys(RESOURCES)) {
        const count = validateSaveNumber(isDefaultZeroResource(id) && values[id] === undefined ? 0 : values[id], 0, state.containers, '集装箱分配');
        if (!Number.isSafeInteger(count))
            throw Error('集装箱分配无效。');
        // Previously supported mithril allocations become idle containers on load.
        if (id === 'mithril') {
            state.containerAssignments[id] = 0;
            continue;
        }
        if (count && !isContainerAssignable(id, state))
            throw Error('集装箱分配无效。');
        state.containerAssignments[id] = count;
    }
    if (countAssignedContainers(state) > state.containers)
        throw Error('已分配集装箱超过持有量。');
    state.alloyContainers = validateSaveNumber(raw.alloyContainers === undefined ? 0 : raw.alloyContainers, 0, calculateAlloyContainerCapacity(state), '合金集装箱');
    if (!Number.isSafeInteger(state.alloyContainers))
        throw Error('合金集装箱数量无效。');
    const alloyAssignments = raw.alloyContainerAssignments;
    if (alloyAssignments !== undefined && (!alloyAssignments || typeof alloyAssignments !== 'object' || Array.isArray(alloyAssignments) || Object.keys(alloyAssignments).some(id => !Object.hasOwn(RESOURCES, id))))
        throw Error('合金集装箱分配无效。');
    const alloyValues = alloyAssignments;
    for (const id of Object.keys(RESOURCES)) {
        const value = alloyValues === undefined ? 0 : alloyValues[id];
        const count = validateSaveNumber(value === undefined && isDefaultZeroResource(id) ? 0 : value, 0, state.alloyContainers, '合金集装箱分配');
        if (!Number.isSafeInteger(count) || (count > 0 && !isContainerAssignable(id, state)))
            throw Error('合金集装箱分配无效。');
        state.alloyContainerAssignments[id] = count;
    }
    if (countAssignedAlloyContainers(state) > state.alloyContainers)
        throw Error('已分配合金集装箱超过持有量。');
}
/** Validate untrusted JSON without coercion; retain existing save error messages. */
function validateSaveNumber(value, min, max, label) {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max)
        throw Error(label + '数据无效。');
    return value;
}
function validateSaveIds(value, dictionary) {
    if (!Array.isArray(value) || new Set(value).size !== value.length || value.some(id => typeof id !== 'string' || !Object.hasOwn(dictionary, id)))
        throw Error('存档项目无效。');
    return [...value];
}
