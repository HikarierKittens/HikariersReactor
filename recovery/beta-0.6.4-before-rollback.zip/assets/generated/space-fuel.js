// GENERATED from src/simulation/space-fuel.ts — do not edit.

const SPACE_BUILDING_IDS = [
    'e710Container', 'e710MiningShip', 'e710Warehouse', 'e710Reactor', 'miningDrone', 'oilExtractor',
    'touristStation', 'solarSatellite', 'researchSatellite', 'orbitalFuelDepot', 'navigationBeacon',
    'moonBase', 'iridiumMine', 'helium3Mine', 'moonObservatory',
    'swarmControlStation', 'swarmSatellite', 'atmosphericCollector', 'galacticFuelDepot', 'talosMoonMiningStation', 'iridiumMiningShip', 'ironMiningShip',
    'asrielSpaceport', 'asrielResidence', 'asrielMine', 'ecologicalDome', 'hangar', 'spaceFactory', 'starRingStation', 'planetaryFoundry', 'spaceGarrison', 'geothermalPlant',
];
/** Waystations reserve whole-unit power before lunar and Asriel maintenance. */
function calculatePoweredWaystations(state, pool, dt = 1) {
    const enabled = Math.max(0, (state.buildings?.spaceWaystation || 0) - (state.stoppedBuildings?.spaceWaystation || 0));
    if (!enabled)
        return 0;
    if (!pool) {
        if (!state.resources)
            return 0;
        pool = { ...state.resources };
        settlePowerPlants(pool, dt, state);
    }
    return Math.min(enabled, Math.floor((Math.max(0, pool.energy) + 1e-8) / (5 * dt)));
}
function reserveWaystationPower(state, pool, dt) {
    const count = calculatePoweredWaystations(state, pool, dt);
    pool.energy = Math.max(0, pool.energy - count * 5 * dt);
    return count;
}
/** Maintenance callers can supply the paid count for the current timestep. */
function calculateSpaceFuelMultiplier(state, count = calculatePoweredWaystations(state)) {
    return Math.max(Number.MIN_VALUE, .95 ** count);
}
function applySpaceFuelDiscount(id, recipe, state) {
    // Also prevents generation previews recursively requesting another power preview.
    if (!SPACE_BUILDING_IDS.includes(id) || !Object.keys(recipe).some(r => r === 'oil' || r === 'helium3'))
        return { ...recipe };
    const factor = calculateSpaceFuelMultiplier(state);
    return Object.fromEntries(Object.entries(recipe).map(([resource, amount]) => [resource,
        (resource === 'oil' || resource === 'helium3') ? Math.max(Number.MIN_VALUE, amount * factor) : amount]));
}
function calculateAsrielMissionCost(state) {
    return Math.max(Number.MIN_VALUE, 5000 * calculateSpaceFuelMultiplier(state));
}
