// GENERATED from src/simulation/refining.ts — do not edit.

const POWERED_METAL_REFINING = Symbol('poweredMetalRefining');
/** Scope an exact settlement count, avoiding recursive support/production previews. */
function withPoweredMetalRefining(state, units, calculate) {
    return calculate({ ...state, [POWERED_METAL_REFINING]: units });
}
function calculatePoweredMetalRefineryUnits(state, dt = 1) {
    if (!state.tech.includes('advancedMetalRefining'))
        return 0;
    return state[POWERED_METAL_REFINING] ?? calculateSupportPreview(state, dt).metalRefineryUnits;
}
/** Whole enabled buildings only; no workers or fractional power grants. */
function settleMetalRefining(state, pool, dt) {
    if (!state.tech.includes('advancedMetalRefining'))
        return 0;
    const running = Math.max(0, (state.buildings.metalRefinery || 0) - (state.stoppedBuildings?.metalRefinery || 0));
    const units = Math.min(running, Math.floor((Math.max(0, pool.energy) + 1e-8) / (4 * dt)));
    pool.energy = Math.max(0, pool.energy - units * 4 * dt);
    return units;
}
function calculateRefiningMultiplier(resource, state) {
    if (!['aluminum', 'metal', 'iridium'].includes(resource))
        return 1;
    const owned = state.buildings.metalRefinery || 0;
    const units = !owned || !state.tech?.includes('advancedMetalRefining') ? 0
        : state[POWERED_METAL_REFINING] ?? (state.resources ? calculatePoweredMetalRefineryUnits(state) : 0);
    return resource === 'aluminum' ? 1 + owned * .06 + units * .02 : 1 + units * (resource === 'iridium' ? .005 : .01);
}
