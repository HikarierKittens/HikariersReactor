// GENERATED from src/simulation/genes.ts — do not edit.


/** Highest level whose next price still fits a safe-integer DNA stock (10·2^49 < 2^53). */
const MAX_GENE_LEVEL = 50;
function createGeneModificationState() {
    return {
        dna: { C: 0, G: 0, A: 0, T: 0 },
        levels: { goodCat: 0, hardWorking: 0, maturationAcceleration: 0, superWorkshop: 0, perfectionism: 0, overclockForging: 0, titanPower: 0, advancedScience: 0, catCohesion: 0, kinoFire: 0 },
        synthesis: { C: 0, G: 0, A: 0, T: 0 },
    };
}
/** 基因合成 per powered 生物科学实验室 and per 1% rate: 2000 knowledge/s → 0.01 base/s (10% = 20k → 0.1). */
const GENE_SYNTHESIS_KNOWLEDGE_PER_PERCENT = 2000;
const GENE_SYNTHESIS_DNA_PER_PERCENT = .01;
const MAX_GENE_SYNTHESIS_RATE = 100;
/** The lab panel needs the tech plus an active 基因修饰 (基因剪切 + this run's 基因测序). */
function isGeneSynthesisUnlocked(state) {
    return state.tech.includes('geneSynthesis') && isGeneModificationUnlocked(state);
}
/** Set one base's synthesis rate (integer percent, 0–100 each, independent of the others). */
function changeGeneSynthesisRate(state, id, value) {
    if (!isGeneSynthesisUnlocked(state) || !DNA_BASE_IDS.includes(id)
        || !Number.isSafeInteger(value) || value < 0 || value > MAX_GENE_SYNTHESIS_RATE)
        return false;
    const base = id;
    if (state.geneModification.synthesis[base] === value)
        return false;
    state.geneModification.synthesis[base] = value;
    return true;
}
/** Withdraw synthesis knowledge from the pool for the powered labs; scales down evenly when knowledge is short. */
function settleGeneSynthesis(state, pool, dt, labs) {
    const result = { knowledge: 0, dna: {} };
    if (!isGeneSynthesisUnlocked(state) || labs <= 0 || dt <= 0)
        return result;
    const rates = state.geneModification.synthesis;
    const percent = DNA_BASE_IDS.reduce((sum, id) => sum + (rates?.[id] || 0), 0);
    const demand = percent * labs * GENE_SYNTHESIS_KNOWLEDGE_PER_PERCENT * dt;
    if (demand <= 0)
        return result;
    const factor = Math.min(1, Math.max(0, pool.knowledge) / demand);
    if (factor <= 0)
        return result;
    pool.knowledge = Math.max(0, pool.knowledge - demand * factor);
    result.knowledge = demand * factor / dt;
    for (const id of DNA_BASE_IDS)
        if (rates[id])
            result.dna[id] = rates[id] * labs * GENE_SYNTHESIS_DNA_PER_PERCENT * factor;
    return result;
}
/** Credit settled synthesis to the DNA stock and record the knowledge spent. */
function applyGeneSynthesis(state, synthesis, dt) {
    if (!synthesis || synthesis.knowledge <= 0)
        return;
    for (const [id, rate] of Object.entries(synthesis.dna)) {
        state.geneModification.dna[id] = Math.min(Number.MAX_SAFE_INTEGER, state.geneModification.dna[id] + rate * dt);
    }
    recordKnowledgeSpent(state, synthesis.knowledge * dt);
}
/** 基因修饰 needs the permanent 基因剪切 upgrade and this run's completed 基因测序. */
function isGeneModificationUnlocked(state) {
    return state.crispr.includes('geneSplicing') && (state.arpaBuildings.geneSequencing || 0) >= 1;
}
/** Partial legacy/test states without gene records behave as level 0. */
function geneLevel(state, id) {
    return state.geneModification?.levels?.[id] || 0;
}
function geneBonus(state, id) {
    return geneLevel(state, id) * GENE_DEFINITIONS[id].perLevel;
}
/** Secondary per-level bonus (e.g. 超频锻造's artisan bonus); 0 when the gene has none. */
function geneExtraBonus(state, id) {
    return geneLevel(state, id) * (GENE_DEFINITIONS[id].extra?.perLevel || 0);
}
/** Upgrade price in the gene's own DNA base: 10·2^level. */
function calculateGeneUpgradeCost(state, id) {
    return 10 * 2 ** geneLevel(state, id);
}
/** Base-output gene multiplier for one building; applies to all of its outputs. */
function calculateGeneOutputFactor(id, state) {
    const gene = id === 'catCafe' ? 'goodCat'
        : id === 'mine' || id === 'coalMine' ? 'hardWorking'
            : id === 'cementWorkshop' ? 'superWorkshop'
                : id === 'school' || id === 'lab' ? 'advancedScience'
                    : id === 'smelter' ? 'kinoFire' : null;
    return gene ? { gene, factor: 1 + geneBonus(state, gene) } : null;
}
/** Craft up to `count` DNA bases at 200k knowledge each; returns the number crafted. */
function craftDna(state, id, count) {
    if (!isGeneModificationUnlocked(state) || !DNA_BASE_IDS.includes(id)
        || !Number.isSafeInteger(count) || count <= 0)
        return 0;
    const base = id;
    const amount = Math.min(count, Math.floor((state.resources.knowledge + 1e-8) / DNA_KNOWLEDGE_COST), Number.MAX_SAFE_INTEGER - state.geneModification.dna[base]);
    if (amount <= 0)
        return 0;
    const spent = amount * DNA_KNOWLEDGE_COST;
    state.resources.knowledge = Math.max(0, state.resources.knowledge - spent);
    state.geneModification.dna[base] += amount;
    recordKnowledgeSpent(state, spent);
    return amount;
}
/** Spend the gene's DNA base to raise it one level for the current run. */
function upgradeGene(state, id) {
    if (!isGeneModificationUnlocked(state) || !Object.hasOwn(GENE_DEFINITIONS, id))
        return false;
    const gene = id;
    if (geneLevel(state, gene) >= MAX_GENE_LEVEL)
        return false;
    const base = GENE_DEFINITIONS[gene].dna, cost = calculateGeneUpgradeCost(state, gene);
    if (state.geneModification.dna[base] < cost)
        return false;
    state.geneModification.dna[base] -= cost;
    state.geneModification.levels[gene] += 1;
    return true;
}
