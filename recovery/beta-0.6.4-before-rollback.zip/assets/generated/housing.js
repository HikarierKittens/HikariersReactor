// GENERATED from src/simulation/housing.ts — do not edit.


function countRunningBuildings(id, state) {
    // Segmented projects only count complete units (every segmentedRequired segments).
    // segmentEffects projects (彭罗斯球体) work per built segment instead.
    const required = BUILDINGS[id].segmentEffects ? undefined : BUILDINGS[id].segmentedRequired;
    const count = required ? Math.floor((state.buildings[id] || 0) / required) : state.buildings[id] || 0;
    return BUILDINGS[id].alwaysRunning ? count : Math.max(0, count - (state.stoppedBuildings?.[id] || 0));
}
function calculateHousingDetails(state, support, stageThree) {
    return Object.keys(BUILDINGS)
        .filter(id => BUILDINGS[id].cap && (state.buildings[id] || 0) > 0)
        .map(id => {
        const building = BUILDINGS[id], count = state.buildings[id];
        const active = id === 'civilianRouteStation' ? stageThree?.civilian ?? calculateSupportPreview(state).stageThree.civilian : id === 'asrielResidence' ? support.allocations.asrielResidence || 0 : countRunningBuildings(id, state);
        const perBuilding = id === 'asrielResidence'
            ? ((building.cap || 0) * 20 + (support.allocations.ecologicalDome || 0)) / 20
            : (building.cap || 0);
        return { name: building.name, count, active, perBuilding, value: active * perBuilding };
    });
}
