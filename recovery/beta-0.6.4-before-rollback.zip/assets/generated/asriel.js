// GENERATED from src/simulation/asriel.ts — do not edit.

const priority = ['asrielResidence', 'asrielMine', 'ecologicalDome', 'planetaryFoundry', 'alienMaterialLab', 'vrCenter'];
/** Caller supplies the available pool after power generation and lunar maintenance. */
function allocateAsrielSupport(state, resources, dt, waystations = 0, fuelMultiplier = calculateSpaceFuelMultiplier(state)) {
    const running = (id) => Math.max(0, (state.buildings[id] || 0) - (state.stoppedBuildings[id] || 0));
    const ports = Math.min(running('asrielSpaceport'), Math.floor(((resources.helium3 || 0) + 1e-8) / (2 * fuelMultiplier * dt)), Math.floor((resources.energy || 0) / (5 * dt)), Math.floor((resources.food || 0) / (25 * dt)));
    // Port maintenance has priority. The caller has not deducted it yet;
    // reserve it locally without mutating the shared resource pool.
    const towerEnergy = Math.max(0, (resources.energy || 0) - ports * 5 * dt);
    const towers = Math.min(running('asrielControlTower'), Math.floor((towerEnergy + 1e-8) / (2 * dt)));
    const capacity = ports * 4 + towers;
    let available = capacity;
    const allocations = { asrielResidence: 0, asrielMine: 0, ecologicalDome: 0, planetaryFoundry: 0, alienMaterialLab: 0, vrCenter: 0 };
    for (const id of priority) {
        allocations[id] = Math.min(running(id), available);
        available -= allocations[id];
    }
    return { ports, towers, capacity, used: capacity - available, available, allocations, priority, support: capacity };
}
function countAsrielResidents(state, support) {
    return Math.min(state.population, state.workers.asrielResidence || 0, (support.allocations.asrielResidence || 0) * 2);
}
function isSpaceResourceSource(id) {
    // 遥远星际 (hyperspace and alpha-region) ordinary producers also count as space resources.
    return ['iridiumMine', 'helium3Mine', 'asrielMine', 'ecologicalDome', 'atmosphericCollector', 'talosMoonMiningStation', 'iridiumMiningShip', 'ironMiningShip', 'e710MiningShip', 'oilExtractor',
        'iceMiningShip', 'comprehensiveMiningFacility', 'gasCloudMiningShip', 'highTechFarmPlatform', 'metalMiningShip', 'fuelMiningShip', 'adamantiteMiningShip', 'grapheneFactory'].includes(id);
}
function calculateSpaceMultiplier(id, state, support) {
    // Ring bonuses apply only at resource sources, never again to downstream production.
    // Stations are permanently active; laboratories must have remaining Asriel support.
    if (!isSpaceResourceSource(id))
        return 1;
    const coefficient = state.tech.includes('starRingOptimization')
        ? .006 + .0001 * (support.allocations.alienMaterialLab || 0)
        : .005;
    return 1 + coefficient * (state.buildings.starRingStation || 0) * countAsrielResidents(state, support);
}
