// GENERATED from src/state/validate-story.ts — do not edit.

function validateStoryArchive(raw, state) {
    if (!Object.hasOwn(raw, 'story')) {
        state.story = { unlocked: [], read: [] };
    }
    else {
        const value = raw.story;
        if (!value || typeof value !== 'object' || Array.isArray(value))
            throw Error('文明剧情档案无效。');
        const record = value;
        const validIds = (ids) => Array.isArray(ids)
            && ids.every(id => typeof id === 'string' && STORY_CHAPTER_IDS.includes(id))
            && new Set(ids).size === ids.length;
        if (!validIds(record.unlocked) || !validIds(record.read))
            throw Error('文明剧情章节无效。');
        if (record.read.some(id => !record.unlocked.includes(id)))
            throw Error('已读剧情尚未解锁。');
        state.story = { unlocked: [...record.unlocked], read: [...record.read] };
    }
    updateStoryProgress(state);
}
