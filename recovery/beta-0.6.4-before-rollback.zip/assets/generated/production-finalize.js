// GENERATED from src/simulation/production-finalize.ts — do not edit.





function settlePopulationIncome(state, pool, happiness, dt) {
    const catTax = calculateTaxBase(state) * calculateBankerMultiplier(state) * calculateGovernmentMultiplier('cash', state)
        * calculateProductionMultiplier('cash', happiness, state) * calculateParticleMultiplier('cash', state);
    const soldierFur = state.soldiers * .2 * calculateFurMultiplier(state) * calculateProductionMultiplier('fur', happiness, state) * calculateParticleMultiplier('fur', state);
    pool.cash += catTax * dt;
    pool.fur += soldierFur * dt;
    return { catTax, soldierFur };
}
/** Net food reports full demand even when the actual pool reaches zero. */
function finalizeProduction(state, pool, before, dt, snapshot) {
    const foodBefore = pool.food, foodDemand = state.population * calculateFoodPerCat(state);
    pool.food = Math.max(0, pool.food - foodDemand * dt);
    const rates = Object.fromEntries(Object.keys(pool).map(id => [id, (pool[id] - before[id]) / dt]));
    rates.food = (foodBefore - before.food) / dt - foodDemand;
    const capped = { ...pool };
    const caps = calculateStorageTotals(state, snapshot);
    for (const id of Object.keys(capped))
        capped[id] = Math.min(capped[id], caps[id]);
    return { pool: capped, rates, starving: foodBefore + 1e-8 < foodDemand * dt };
}
