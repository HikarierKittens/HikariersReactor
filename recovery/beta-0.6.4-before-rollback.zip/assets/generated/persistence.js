// GENERATED from src/state/persistence.ts — do not edit.
/** Failure is reported without overwriting or resetting the in-memory game. */
function persistGame(state, storage, key, now) {
    const previousSaved = state.lastSaved;
    state.lastSaved = now;
    try {
        storage.setItem(key, JSON.stringify(state));
        return true;
    }
    catch {
        state.lastSaved = previousSaved;
        return false;
    }
}
