// GENERATED from src/simulation/achievement-tracking.ts — do not edit.

const SNAPSHOT_ACHIEVEMENT_IDS = [
    'artificialCelestial', 'swarmEclipse', 'worldExecution', 'overclockPrince',
];
/** Fresh runs can earn their first false -> true transition. */
function createAchievementTracking() {
    return { artificialCelestial: false, swarmEclipse: false, worldExecution: false, overclockPrince: false };
}
/** Baseline legacy saves at their current conditions, never at historical progress. */
function snapshotAchievementConditions(state) {
    return Object.fromEntries(SNAPSHOT_ACHIEVEMENT_IDS.map(id => [id, ACHIEVEMENTS[id].test(state)]));
}
/** Snapshot awards only; reset-event achievements must be granted by successful resets. */
function updateAchievementTracking(state) {
    const current = snapshotAchievementConditions(state);
    const previous = state.achievementTracking;
    const unlocked = [];
    for (const id of SNAPSHOT_ACHIEVEMENT_IDS) {
        if (previous?.[id] === false && current[id] && !state.achievements.includes(id)) {
            state.achievements.push(id);
            unlocked.push(id);
        }
    }
    // Missing runtime tracking is treated like an imported legacy baseline too.
    state.achievementTracking = current;
    return unlocked;
}
