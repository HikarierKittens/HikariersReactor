// GENERATED from src/simulation/factory-settlement.ts — do not edit.









function isFactoryLineUnlocked(id, state) {
    const option = FACTORY_OPTIONS.find(item => item.id === id);
    if (!option || (option.tech && !state.tech.includes(option.tech)))
        return false;
    if (id === 'fur')
        return state.buildings.factory > 0;
    const tech = RESOURCES[option.id].tech;
    return (!tech || state.tech.includes(tech)) && isResourceUnlocked(id, state);
}
function settleFactoryLines(state, pool, dt, happiness, support, fuelMultiplier, quantumLevel = 0) {
    const quantumMultiplier = calculateQuantumManufacturingMultiplier(state, quantumLevel);
    const inputs = {}, outputs = {};
    const ground = Math.min(countRunningBuildings('factory', state), Math.max(0, pool.energy) / (3 * dt));
    inputs.factory = outputs.factory = ground;
    pool.energy = Math.max(0, pool.energy - ground * 3 * dt);
    const fuel = fuelMultiplier === undefined ? calculateBuildingInput('spaceFactory', state).helium3 || 0 : 2 * fuelMultiplier;
    const space = Math.min(countRunningBuildings('spaceFactory', state), Math.max(0, pool.energy) / (3 * dt), Math.max(0, pool.helium3) / (fuel * dt));
    inputs.spaceFactory = outputs.spaceFactory = space;
    pool.energy = Math.max(0, pool.energy - space * 3 * dt);
    pool.helium3 = Math.max(0, pool.helium3 - space * fuel * dt);
    // 高科技工厂: 2 lines per funded factory, paid with energy + deuterium after space factories.
    const highTechRecipe = Object.entries(calculateBuildingInput('highTechFactory', state));
    let highTech = countRunningBuildings('highTechFactory', state);
    for (const [id, value] of highTechRecipe)
        highTech = Math.min(highTech, Math.max(0, pool[id] || 0) / (value * dt));
    inputs.highTechFactory = outputs.highTechFactory = highTech;
    for (const [id, value] of highTechRecipe)
        pool[id] = Math.max(0, pool[id] - value * highTech * dt);
    // Powered line capacity weighs each factory by its own line count.
    const poweredLines = ground + space + highTech * (BUILDINGS.highTechFactory.lines || 0);
    const powerRatio = Math.min(1, poweredLines / (countAssignedLines(state) || 1));
    for (const option of FACTORY_OPTIONS) {
        const units = state.lines[option.id] || 0;
        if (!units || !isFactoryLineUnlocked(option.id, state))
            continue;
        const recipe = calculateFactoryRecipe(option.id, state);
        const ingredients = Object.entries(recipe.input);
        const products = Object.entries(recipe.output);
        let ratio = powerRatio;
        for (const [id, value] of ingredients)
            ratio = Math.min(ratio, pool[id] / (value * units * dt || 1));
        const actual = units * Math.max(0, ratio);
        inputs[option.id] = outputs[option.id] = actual;
        for (const [id, value] of ingredients)
            pool[id] = Math.max(0, pool[id] - value * actual * dt);
        // Current factory recipes never produce knowledge; keep that contract explicit.
        for (const [id, value] of products)
            pool[id] += value * actual * calculateFactoryOutputMultiplier(id, happiness, state, 1) * quantumMultiplier * dt;
        for (const [id, value] of products)
            if (space > 0 && id !== 'energy' && id !== 'knowledge') {
                const share = space / (poweredLines || 1);
                pool[id] += value * actual * calculateFactoryOutputMultiplier(id, happiness, state, 1) * quantumMultiplier * dt * share * (calculateSpaceMultiplier('spaceFactory', state, support) - 1);
            }
    }
    return { inputs, outputs };
}
