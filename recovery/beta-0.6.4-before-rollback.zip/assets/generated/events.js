// GENERATED from src/simulation/events.ts — do not edit.


function sampleEventInterval(random) {
    return CONFIG.eventMin + random() * (CONFIG.eventMax - CONFIG.eventMin);
}
/** Returns the notification text; storage capacity and randomness are explicit inputs. */
function applyRandomEvent(state, random, metalCapacity) {
    const choices = EVENTS.filter(event => !event.tech || state.tech.includes(event.tech));
    state.eventIn = sampleEventInterval(random);
    if (!choices.length)
        return null;
    const event = choices[Math.floor(random() * choices.length)];
    return event?.name ?? null;
}
