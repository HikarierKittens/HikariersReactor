// GENERATED from src/state/validate-genes.ts — do not edit.



// Unique name: the VM regression bridge loads every module into one global scope.
function geneSaveObject(value, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw Error(`${label}无效。`);
    return value;
}
/** Sticky prestige unlocks. Older saves infer them from holdings and permanent history.
 * Call after prestige counters and CRISPR purchases are validated. */
function validatePrestigeUnlocks(raw, state) {
    const value = raw.prestigeUnlocked;
    if (value === undefined) {
        const unlocked = [];
        if (state.crispr.length || state.prestige.nuclearResets + state.prestige.escapeResets + state.prestige.blackHoleResets > 0)
            unlocked.push('particles');
        if (state.prestige.escapeResets + state.prestige.blackHoleResets > 0)
            unlocked.push('casimir');
        if (state.prestige.blackHoleResets > 0)
            unlocked.push('darkEnergy');
        state.prestigeUnlocked = unlocked;
    }
    else {
        if (!Array.isArray(value) || new Set(value).size !== value.length
            || value.some(id => typeof id !== 'string' || !PRESTIGE_RESOURCE_IDS.includes(id)))
            throw Error('威望资源解锁记录无效。');
        state.prestigeUnlocked = [...value];
    }
    syncPrestigeUnlocks(state);
}
/** Run-scoped gene records; absent records (older saves) start empty at level 0. */
function validateGeneModification(raw, state) {
    const fresh = createGeneModificationState();
    if (raw.geneModification === undefined) {
        state.geneModification = fresh;
        return;
    }
    const source = geneSaveObject(raw.geneModification, '基因修饰记录');
    const dna = geneSaveObject(source.dna ?? {}, 'DNA记录'), levels = geneSaveObject(source.levels ?? {}, '基因等级');
    const synthesis = geneSaveObject(source.synthesis ?? {}, '基因合成速率');
    const isBase = (key) => DNA_BASE_IDS.includes(key);
    if (Object.keys(source).some(key => key !== 'dna' && key !== 'levels' && key !== 'synthesis')
        || Object.keys(dna).some(key => !isBase(key)) || Object.keys(synthesis).some(key => !isBase(key))
        || Object.keys(levels).some(key => !Object.hasOwn(GENE_DEFINITIONS, key)))
        throw Error('基因修饰记录无效。');
    for (const id of DNA_BASE_IDS) {
        // 基因合成 produces fractional DNA; crafting and upgrades keep whole amounts.
        const amount = dna[id] ?? 0;
        if (typeof amount !== 'number' || !Number.isFinite(amount) || amount < 0 || amount > Number.MAX_SAFE_INTEGER)
            throw Error('DNA数量无效。');
        fresh.dna[id] = amount;
        const rate = synthesis[id] ?? 0;
        if (!Number.isSafeInteger(rate) || rate < 0 || rate > MAX_GENE_SYNTHESIS_RATE)
            throw Error('基因合成速率无效。');
        fresh.synthesis[id] = rate;
    }
    for (const id of Object.keys(GENE_DEFINITIONS)) {
        const level = levels[id] ?? 0;
        if (!Number.isSafeInteger(level) || level < 0 || level > MAX_GENE_LEVEL)
            throw Error('基因等级无效。');
        fresh.levels[id] = level;
    }
    state.geneModification = fresh;
}
