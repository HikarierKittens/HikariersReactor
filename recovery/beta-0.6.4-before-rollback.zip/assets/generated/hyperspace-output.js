// GENERATED from src/simulation/hyperspace-output.ts — do not edit.

/** Funded-ratio producers in 遥远星际 (hyperspace regions plus 天元六alpha星区). */
const HYPERSPACE_SOURCE_IDS = ['comprehensiveMiningFacility', 'gasCloudMiningShip', 'highTechFarmPlatform', 'metalMiningShip', 'fuelMiningShip', 'adamantiteMiningShip', 'grapheneFactory'];
/** Hyperspace buildings with maintenance but no resource output (settled after the sources). */
const HYPERSPACE_CONSUMER_IDS = ['e710ResearchStation', 'blackHoleStation', 'massEjector'];
function isHyperspaceSource(id) {
    return id === 'iceMiningShip' || HYPERSPACE_SOURCE_IDS.includes(id);
}
/** Resource-local factor. The former 超空间太空港 +25% bonus was removed; fundedPorts is kept for call-site stability. */
function calculateHyperspaceOutputFactor(resource, state, happiness, fundedPorts) {
    void fundedPorts;
    return calculateProductionMultiplier(resource, happiness, state);
}
/** Only whole powered, running 精金加工站 grant the miner bonus. Callers pass the settled units. */
function calculateHyperspaceLocalMultiplier(id, state, fundedProcessors = 0) {
    void state;
    return id === 'adamantiteMiningShip' ? 1 + .1 * fundedProcessors : 1;
}
