// GENERATED from src/simulation/progression.ts — do not edit.








/** Newest-first capped log; the caller owns every notification decision. */
function addLog(state, text, type = 'progress') {
    const safe = LOG_TYPES.includes(type) ? type : 'progress';
    state.logs.unshift({ time: state.time, text: stripEmoji(text), type: safe });
    state.logs = state.logs.slice(0, 80);
}
/** Apply sticky unlocks and return new achievements for caller-owned notifications. */
function updateProgression(state) {
    for (const id of Object.keys(RESOURCES)) {
        if (meetsResourceUnlock(id, state) && !state.unlockedResources.includes(id))
            state.unlockedResources.push(id);
    }
    syncPrestigeUnlocks(state);
    updateStageThreeProgress(state);
    updateStoryProgress(state);
    if (isResourceUnlocked('fur', state))
        state.furUnlocked = true;
    return updateAchievementTracking(state);
}
