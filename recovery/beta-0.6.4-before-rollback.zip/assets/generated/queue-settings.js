// GENERATED from src/simulation/queue-settings.ts — do not edit.



/** Each construction project occupies one slot, including segmented batches. */
function buildingQueueUsage(queue) {
    return queue.filter(item => item.kind !== 'tech').length;
}
/** Remaining physical segments reserved by projects, not their slot count. */
function queuedBuildingSegments(queue, id) {
    return queue.reduce((sum, item) => sum + (item.kind === 'build' && item.id === id ? item.segments ?? 1 : 0), 0);
}
function segmentedQueueBatchSize(id) {
    return Math.max(1, Math.ceil((BUILDINGS[id].segmentedRequired || 1) * .1));
}
/** One capacity policy for purchases, ARPA and queue displays; explicit zero disables a lane. */
function purchaseQueueCapacity(state, kind) {
    const multiplier = state.crispr?.includes('architect') ? 2 : 1;
    const explicit = state.queueCapacity?.[kind];
    if (Number.isFinite(explicit))
        return Math.max(0, Math.floor(explicit)) * multiplier;
    const defs = TECHNOLOGIES;
    const aliases = kind === 'build'
        ? ['buildingQueueCapacity', 'constructionQueueCapacity', 'buildingQueue']
        : ['researchQueueCapacity', 'technologyQueueCapacity', 'researchQueue'];
    let extra = 0;
    for (const id of state.tech) {
        const def = defs[id];
        const effect = def?.queueCapacity;
        const directBonus = kind === 'build' ? def?.buildingQueueBonus : def?.researchQueueBonus;
        if (typeof directBonus === 'number' && Number.isFinite(directBonus))
            extra += directBonus;
        if (effect && typeof effect === 'object') {
            const value = effect[kind];
            if (typeof value === 'number' && Number.isFinite(value))
                extra += value;
        }
        for (const alias of aliases)
            if (id === alias)
                extra++;
    }
    return Math.max(2, Math.floor(2 + extra)) * multiplier;
}
function buildingQueueCapacity(state) { return purchaseQueueCapacity(state, 'build'); }
function researchQueueCapacity(state) { return purchaseQueueCapacity(state, 'tech'); }
function isQueueSettingEnabled(state, key) {
    return state.settings?.[key] ?? DEFAULT_GAME_SETTINGS[key];
}
