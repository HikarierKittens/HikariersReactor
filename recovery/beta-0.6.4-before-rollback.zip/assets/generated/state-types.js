// GENERATED from src/types/state.ts — do not edit.
const DEFAULT_GAME_SETTINGS = {
    paused: false,
    alwaysEnableNewBuildings: false,
    unorderedBuildingQueue: true,
    queueHotkeys: true,
    unorderedResearchQueue: true,
    touchOptimization: false,
};
