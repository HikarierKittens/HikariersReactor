// GENERATED from src/simulation/government.ts — do not edit.



const GOVERNMENTS = {
    none: { name: '无政府体制', tech: 'government', desc: '没有额外效果。' },
    democracy: { name: '民主', tech: 'government', desc: '每位艺术家幸福度效果额外+0.5个百分点。' },
    militaryRule: { name: '军政', tech: 'government', desc: '士兵战斗力+20%，训练速度+30%，士兵工作压力+50%。' },
    oligarchy: { name: '寡头', tech: 'government', desc: '猫猫税收+25%，幸福度−10个百分点。' },
    technocracy: { name: '科技至上', tech: 'advancedGovernment', desc: '科技知识成本−8%，所有知识产量+10%。' },
    industrialism: { name: '工业至上', tech: 'advancedGovernment', desc: '工厂所有产量+25%；仅地面工厂成本递增系数降低0.005。' },
};
const GOVERNMENT_COOLDOWN = 2000;
function availableGovernments(state) {
    return Object.keys(GOVERNMENTS).filter(id => state.tech.includes(GOVERNMENTS[id].tech)).map(id => ({ id, ...GOVERNMENTS[id] }));
}
function reformCooldown(state) {
    return state.lastReformTime === null ? 0 : Math.max(0, GOVERNMENT_COOLDOWN - (state.time - state.lastReformTime));
}
function calculateTechCost(id, state) {
    return Object.fromEntries(Object.entries(TECHNOLOGIES[id].cost).map(([r, v]) => [r, r === 'knowledge' && state.government === 'technocracy' ? Math.ceil(v * .92) : v]));
}
/** Owned ceiling for save validation and existing capacity-based army pressure.
 * Stopping or starving a garrison never deletes already trained soldiers. */
function calculateSoldierCapacity(state) { return ((state.buildings.barracks || 0) + (state.buildings.spaceGarrison || 0)) * 2; }
/** Only whole paid garrisons can open new training places. */
function calculateOperationalSoldierCapacity(state, paidGarrisonUnits) {
    const running = Math.max(0, (state.buildings.spaceGarrison || 0) - (state.stoppedBuildings?.spaceGarrison || 0));
    return (state.buildings.barracks || 0) * 2 + Math.floor(Math.min(running, Math.max(0, paidGarrisonUnits)) + 1e-9) * 2;
}
function calculateCombatPower(state) { return (state.tech.includes('ironEquipment') ? 2 : 1) * (state.government === 'militaryRule' ? 1.2 : 1) * (1 + geneBonus(state, 'titanPower')); }
/** 猫猫凝聚 scales soldier-capacity pressure by half its population rate. */
function calculateSoldierPressure(state) { return calculateSoldierCapacity(state) * (state.government === 'militaryRule' ? 1.5 : 1) * Math.max(0, 1 - geneBonus(state, 'catCohesion') / 2); }
/** 猫猫凝聚 scales the 0.5-per-cat population pressure. */
function calculatePopulationPressure(state) { return state.population * .5 * Math.max(0, 1 - geneBonus(state, 'catCohesion')); }
function calculateGovernmentMultiplier(resource, state) { return resource === 'cash' && state.government === 'oligarchy' ? 1.25 : resource === 'knowledge' && state.government === 'technocracy' ? 1.1 : 1; }
function calculateFurMultiplier(state) { return state.tech.includes('ironEquipment') ? 1.2 : 1; }
/** Per-banker tax bonus: 5% base, +2 percentage points per 证券交易所 (additive). */
const BANKER_TAX_BONUS = .05;
const STOCK_EXCHANGE_BANKER_BONUS = .02;
function calculateBankerTaxRate(state) {
    return BANKER_TAX_BONUS + STOCK_EXCHANGE_BANKER_BONUS * (state.arpaBuildings?.stockExchange || 0);
}
function calculateBankerMultiplier(state) { return 1 + (state.workers.bank || 0) * calculateBankerTaxRate(state); }
function calculateTaxBase(state) { return state.population * state.taxRate / 20; }
/** Per-camp training effect in percent: 5%, or 8% after 虚拟训练. */
function calculateTrainingBoost(state) { return state.tech?.includes('virtualTraining') ? 8 : BUILDINGS.trainingCamp.trainingBoost ?? 0; }
function calculateTrainingDuration(state) { return 30 / 2 ** ((state.buildings.trainingCamp || 0) * calculateTrainingBoost(state) / 100) / (state.government === 'militaryRule' ? 1.3 : 1); }
function calculatePrestigeReward(state) { const raw = state.population / 4 + state.soldiers / 2 + 10; return Math.floor(raw <= 150 ? raw : 150 + (raw - 150) / 4); }
/** Escape rewards use the population remaining aboard at launch, including soldiers. */
function calculateEscapePrestigeReward(state) {
    const raw = (state.population + state.soldiers) / 3 + 100;
    return Math.floor(raw <= 400 ? raw : 400 + (raw - 400) * .25);
}
/** Casimir is awarded from the final integer particle reward, not its uncapped base. */
function calculateCasimirReward(particleReward) {
    const raw = particleReward / 8;
    return Math.floor(raw <= 100 ? raw : 100 + (raw - 100) * .05);
}
/** 黑洞重置 particles: larger base and a later, gentler soft cap than escape. */
function calculateBlackHoleParticleReward(state) {
    const raw = (state.population + state.soldiers) / 2 + 250;
    return Math.floor(raw <= 800 ? raw : 800 + (raw - 800) * .3);
}
/** 黑洞重置 Casimir from the final particle reward, with a higher soft cap than escape. */
function calculateBlackHoleCasimirReward(particleReward) {
    const raw = particleReward / 6;
    return Math.floor(raw <= 150 ? raw : 150 + (raw - 150) * .1);
}
