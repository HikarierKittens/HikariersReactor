// GENERATED from src/simulation/containers.ts — do not edit.



/** 超级集装箱 raises 集装仓库 to 25; 中子库 replaces 格纳库's ordinary cap with 40. */
function calculateBuildingContainerCap(id, state) {
    if (id === 'hangar' && state.tech.includes('neutronVault'))
        return 40;
    if (id === 'containerWarehouse' && state.tech.includes('superContainers'))
        return 25;
    return BUILDINGS[id].containerCap || 0;
}
function calculateContainerCapacity(state) {
    return Object.keys(BUILDINGS).reduce((sum, id) => sum + calculateBuildingContainerCap(id, state) * state.buildings[id], 0);
}
/** Alloy slots require 超级集装箱: 集装仓库 10, 格纳库 15 (replaced by 25 with 中子库). */
function calculateBuildingAlloyContainerCap(id, state) {
    if (!state.tech.includes('superContainers'))
        return 0;
    return id === 'containerWarehouse' ? 10 : id === 'hangar' ? (state.tech.includes('neutronVault') ? 25 : 15) : 0;
}
function calculateAlloyContainerCapacity(state) {
    return ['containerWarehouse', 'hangar'].reduce((sum, id) => sum + calculateBuildingAlloyContainerCap(id, state) * (state.buildings[id] || 0), 0);
}
function countAssignedAlloyContainers(state) {
    return Object.values(state.alloyContainerAssignments).reduce((sum, count) => sum + count, 0);
}
function calculateSpaceContainerCapacity(state) {
    return Object.keys(BUILDINGS).reduce((sum, id) => sum + (BUILDINGS[id].spaceContainerCap || 0) * state.buildings[id], 0);
}
function countAssignedContainers(state) {
    return Object.values(state.containerAssignments).reduce((sum, count) => sum + count, 0);
}
function isContainerAssignable(id, state) {
    return Object.hasOwn(RESOURCES, id) && !RESOURCES[id].special
        && !['water', 'oil', 'uranium', 'cash', 'helium3', 'deuterium', 'mithril', 'neutron', 'e710', 'nanotubes', 'aerogel'].includes(id) && isResourceUnlocked(id, state);
}
function calculateContainerUnitCapacity(state) {
    // 250 base; 钢集装箱 ×2, 强化集装箱 ×2, 铱合金集装箱 ×2.5 (1000 → 2500 with all three).
    return (state.tech.includes('steelContainers') ? 500 : 250) * (state.tech.includes('reinforcedContainers') ? 2 : 1)
        * (state.tech.includes('iridiumAlloyContainers') ? 2.5 : 1);
}
/** Four ordinary containers' worth, sharing every container upgrade. */
function calculateAlloyContainerUnitCapacity(state) {
    return 4 * calculateContainerUnitCapacity(state);
}
const ALLOY_CONTAINER_RECIPE = { alloy: 10 };
function calculateContainerRecipe(state) {
    return state.tech.includes('steelContainers') ? { metal: 50 } : { iron: 25 };
}
