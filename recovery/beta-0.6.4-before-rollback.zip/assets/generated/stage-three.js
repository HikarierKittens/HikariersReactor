// GENERATED from src/simulation/stage-three.ts — do not edit.
/** Previewing production never calls this: activation requires a committed simulation tick. */
function updateStageThreeProgress(state, result) {
    if (result && (result.inputUnits.aiSupercore || 0) > 0)
        state.stageThree.coreActivated = true;
}
/** Mapping the anomaly opens the 超空间 world view directly. */
function isHyperspaceUnlocked(state) {
    return state.tech.includes('anomalyMapping');
}
/** Stage three has begun, but the anomaly has not yet been mapped. */
function isEarlyStageThree(state) {
    return state.stageThree.coreActivated && !isHyperspaceUnlocked(state);
}
