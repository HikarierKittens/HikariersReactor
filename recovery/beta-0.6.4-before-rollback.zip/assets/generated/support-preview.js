// GENERATED from src/simulation/support-preview.ts — do not edit.




/**
 * Read-only reservation using the production settlements in their exact order.
 * Space source maintenance must be included before powered storage/research;
 * otherwise low-power previews can grant capacity that production cannot run.
 */
function calculateSupportPreview(state, dt = 1, quantumLevel) {
    return buildSettlementLedger(state, dt, quantumLevel);
}
/** Shared single settlement: also returns the raw space settlement for production. */
function buildSettlementLedger(state, dt = 1, quantumLevel) {
    if (!Number.isFinite(dt) || dt <= 0)
        throw new RangeError('dt must be positive and finite');
    const pool = { ...state.resources };
    const aiSupercoreUnits = settleQuantumCores(state, pool, dt);
    const plants = settlePowerPlants(pool, dt, state, quantumLevel);
    // Happiness only scales ordinary space outputs, never power or maintenance.
    const space = settleSpaceProduction(state, pool, dt, 1, plants.inputUnits.geothermalPlant || 0, plants.inputUnits.hydrogenPowerPlant || 0);
    const e710WarehouseUnits = settleE710WarehousePower(state, pool, dt);
    const biologyRunning = Math.max(0, (state.buildings.biologyLab || 0) - (state.stoppedBuildings?.biologyLab || 0));
    const biologyUnits = Math.min(biologyRunning, Math.floor((Math.max(0, pool.energy) + 1e-8) / (2 * dt)));
    pool.energy = Math.max(0, pool.energy - biologyUnits * 2 * dt);
    const dataRunning = Math.max(0, (state.buildings.observatory || 0) - (state.stoppedBuildings?.observatory || 0));
    const dataCenterUnits = Math.min(dataRunning, Math.floor((Math.max(0, pool.energy) + 1e-8) / (3 * dt)));
    // Preserve the research-power API: pool reserves biology but not observatories.
    return {
        stageThree: space.stageThree,
        pool, moon: space.moon, asriel: space.asriel, metalRefineryUnits: space.metalRefineryUnits,
        biologyUnits, dataCenterUnits,
        waystations: space.inputs.spaceWaystation || 0,
        e710ContainerUnits: space.e710ContainerUnits, e710WarehouseUnits, aiSupercoreUnits,
        ironMiningShips: space.inputs.ironMiningShip || 0,
        researchStationUnits: space.inputs.e710ResearchStation || 0,
        blackHoleStationUnits: space.inputs.blackHoleStation || 0,
        space,
        plants,
    };
}
