// GENERATED from src/simulation/challenges.ts — do not edit.

const CHALLENGE_GENE_IDS = ['particleImbalance', 'geneCollapse', 'industrialFracture'];
/** Legacy callers without challenge records behave like an ordinary run. */
function isChallengeGeneActive(state, id) {
    return state.challenge?.genes.includes(id) ?? false;
}
/** Starting particles are inert in particle imbalance, but newly earned particles work normally. */
function calculateEffectiveParticleCount(state) {
    return Math.max(0, state.prestige.particles - (isChallengeGeneActive(state, 'particleImbalance') ? state.challenge?.particleBaseline ?? 0 : 0));
}
function canLaunchChallenges(state) {
    return state.crispr.includes('challengeGene');
}
/** Selection is a UI draft until this explicit, atomic soft-reset command succeeds. */
function launchChallenges(state, selectedGenes, eventIn, now) {
    if (!canLaunchChallenges(state) || !Array.isArray(selectedGenes) || !selectedGenes.length
        || selectedGenes.some(id => !CHALLENGE_GENE_IDS.includes(id)) || new Set(selectedGenes).size !== selectedGenes.length
        || !Number.isSafeInteger(state.prestige.particles) || state.prestige.particles < 0)
        return null;
    const reset = resetRunState(state, 'soft', eventIn, now);
    if (!reset)
        return null;
    reset.next.challenge = { genes: [...selectedGenes], modes: [], story: null, particleBaseline: state.prestige.particles };
    return reset;
}
