// GENERATED from src/simulation/costs.ts — do not edit.






/** Build a price context once per display revision; never authorizes a payment by itself. */
function buildPriceContext(state, dt = 1) {
    const context = {};
    if (state.tech?.includes('quantumSwarm') && state.resources)
        context.quantumLevel = calculateQuantumLevel(state, dt);
    context.ironMiningShips = calculateSupportPreview(state, dt).ironMiningShips;
    return context;
}
/** Collect every active dynamic creep contribution for one building/resource. */
function calculateDynamicCreep(id, resource, state) {
    const terms = [];
    // Segmented projects have a permanent creep of exactly 1: no dynamic term may apply.
    if (BUILDINGS[id].segmentedRequired)
        return terms;
    const crispr = calculateCrisprCostReduction(state);
    if (crispr)
        terms.push({ label: 'CRISPR 材料基因', value: -crispr });
    if (id === 'factory' && state.government === 'industrialism')
        terms.push({ label: '工业至上体制', value: -.005 });
    if (['nest', 'nestMKII'].includes(id) && state.tech?.includes('steelBuildingMaterials'))
        terms.push({ label: '钢制建材', value: -.01 });
    if (['nest', 'nestMKII'].includes(id) && state.tech?.includes('neutronConstructionMaterials'))
        terms.push({ label: '中子结构建材', value: -.01 });
    return terms;
}
/** Lowest actual creep any ordinary building may reach after all dynamic reductions. */
const MIN_BUILDING_SCALE = 1.005;
/** Actual creep = base (registry scale) + Σ dynamic terms, floored at MIN_BUILDING_SCALE.
 * Exempt: segmented projects (fixed creep 1) and explicitly specified registry scales that
 * are already below the floor (e.g. the once-only 星际船坞 at 1), which keep their own value. */
function calculateBuildingScale(id, resource, state) {
    const scale = BUILDINGS[id].costScales?.[resource];
    if (scale === undefined)
        throw new Error(`Missing cost scale: ${id}/${resource}`);
    const dynamic = calculateDynamicCreep(id, resource, state).reduce((sum, term) => sum + term.value, 0);
    const floor = BUILDINGS[id].segmentedRequired || scale < MIN_BUILDING_SCALE ? Math.min(1, scale) : MIN_BUILDING_SCALE;
    return Math.max(floor, Number((scale + dynamic).toFixed(12)));
}
/** True when a once-only building (max count or segmented completion) is fully built.
 * AI超级核心 is the only segmented building (100 segments, no further max);
 * communityCenter is the only max:1 building; all other buildings have no cap. */
function isBuildingFullyBuilt(id, state) {
    const building = BUILDINGS[id];
    const owned = state.buildings[id] || 0;
    if (building.segmentedRequired) {
        const segments = building.max ?? building.segmentedRequired;
        return owned >= segments;
    }
    return building.max !== undefined && owned >= building.max;
}
function calculateBuildingCost(id, count, state, context) {
    // Segmented projects (AI超级核心, 空间撕裂者) always charge the fixed per-segment
    // price: creep is exactly 1 and dynamic creep terms (CRISPR etc.) never apply.
    if (BUILDINGS[id].segmentedRequired)
        return { ...BUILDINGS[id].cost };
    let logDiscount = 0;
    if (id === 'swarmSatellite') {
        const quantum = state.tech?.includes('quantumSwarm') && state.resources
            ? context?.quantumLevel ?? calculateQuantumLevel(state)
            : 0;
        const percent = .1 + (state.tech?.includes('quantumSwarm') ? Math.floor(quantum / 5) * .01 : 0);
        const factories = state.buildings?.swarmFactory || 0;
        logDiscount = factories > 0 ? factories * Math.log(Math.max(Number.MIN_VALUE, 1 - percent)) : 0;
    }
    if (id === 'swarmFactory' && state.tech?.includes('swarmFactoryOptimization') && state.resources) {
        const ironShips = context?.ironMiningShips ?? (calculateProduction(state).inputUnits.ironMiningShip || 0);
        logDiscount = ironShips * Math.log(.95);
    }
    const discounted = logDiscount !== 0;
    return applySpaceFuelDiscount(id, Object.fromEntries(Object.entries(BUILDINGS[id].cost)
        .filter(([resource]) => resource !== 'cash' || id !== 'nest' || count >= 5)
        .map(([resource, value]) => {
        const scale = calculateBuildingScale(id, resource, state);
        const residence = id === 'asrielResidence' && state.tech?.includes('neutronConstructionMaterials') ? .85 : 1;
        // Log-space multiplication prevents Infinity * 0 when scale and discounts oppose.
        const price = discounted
            ? Math.max(Number.MIN_VALUE, Math.exp(Math.log(value) + count * Math.log(scale) + Math.log(residence) + logDiscount))
            : Math.ceil(value * scale ** count * residence);
        return [resource, price];
    })), state);
}
function canPayCost(resources, cost) {
    return Object.entries(cost).every(([id, value]) => Number.isFinite(value) && value >= 0 && resources[id] + 1e-8 >= value);
}
/** All-or-nothing payment. The epsilon and floor preserve existing save/economy behavior. */
function payResourceCost(resources, cost) {
    if (!canPayCost(resources, cost))
        return false;
    for (const [id, value] of Object.entries(cost))
        resources[id] = Math.max(0, resources[id] - value);
    return true;
}
