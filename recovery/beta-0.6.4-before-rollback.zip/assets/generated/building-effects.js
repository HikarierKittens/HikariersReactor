// GENERATED from src/simulation/building-effects.ts — do not edit.
/** Coefficients shared with the settlement so tooltip text cannot drift from gameplay. */
const ARRAY_STABILITY = 2;
const REPEATER_BONUS_PER_ARRAY = .25;
const SPACEPORT_STABILITY = 4;
const SPACEPORT_ASTEROID_SUPPORT = 2;
const ASTEROID_UNIT_SUPPORT_COST = 1;
const ASTEROID_BASE_FREIGHT_BONUS = .05;
/** Knowledge cap bonus per complete 空间撕裂者: 20% plus 1% per funded 黑洞星际站 (shared with storage totals). */
function calculateRipperKnowledgeBonusValue(blackHoleStations) {
    return SPACE_RIPPER_KNOWLEDGE_BONUS + BLACK_HOLE_STATION_RIPPER_BONUS * blackHoleStations;
}
function percent(value) { return `${Number((value * 100).toFixed(4))}%`; }
/** Build the shared effect rows for hyperspace stability and asteroid support buildings. */
function getBuildingEffectRows(id, state, snapshot) {
    const repeaters = snapshot.repeaters || 0;
    const asteroidBases = snapshot.asteroidBases || 0;
    switch (id) {
        case 'constraintArray':
            return [{ label: '运行时：稳定度', value: `+${2 + REPEATER_BONUS_PER_ARRAY * repeaters}` }];
        case 'signalRepeater':
            return [{ label: '每座运行阵列稳定度', value: `+${REPEATER_BONUS_PER_ARRAY}`, note: '按运行中继数量累加。' }];
        case 'hydrogenPowerPlant':
            return [{ label: '运行时：喷发小行星群支持', value: '+1' }];
        case 'hyperspaceSpaceport':
            return [
                { label: '运行时：接入点稳定度', value: `+${SPACEPORT_STABILITY}` },
                { label: '运行时：喷发小行星群支持', value: `+${SPACEPORT_ASTEROID_SUPPORT}` },
            ];
        case 'iceMiningShip':
        case 'asteroidBase':
            return [{ label: '占用喷发小行星群支持', value: '1' }];
        case 'massEjector':
            return [{ label: '喷射容量', value: '+1000/s', note: '需完整供电；在资源管理 → 质量喷射中分配。' }];
        case 'spaceRipper': {
            const stations = snapshot.blackHoleStations || 0;
            return [{ label: '知识容量', value: `+${percent(calculateRipperKnowledgeBonusValue(stations))}`,
                    note: stations ? `建成完整撕裂者后生效；含${stations}座供能黑洞星际站+${percent(BLACK_HOLE_STATION_RIPPER_BONUS * stations)}。` : '建成完整撕裂者后生效。' }];
        }
        default:
            return [];
    }
}
/** Long-form stacking explanation that follows the numeric value on its own row. */
function getBuildingEffectNotes(id) {
    if (id === 'asteroidBase')
        return ['仅运行时生效，按运行基地数量累加。'];
    return [];
}
/** Freight capacity multiplier contributed by running asteroid bases (additive per base). */
function calculateAsteroidFreightMultiplier(asteroidBases) {
    return 1 + ASTEROID_BASE_FREIGHT_BONUS * asteroidBases;
}
/** Knowledge cap bonus per complete 空间撕裂者 core (scales the final knowledge subtotal). */
const SPACE_RIPPER_KNOWLEDGE_BONUS = .2;
/** Each funded 黑洞星际站 adds this to every complete 空间撕裂者's knowledge cap bonus. */
const BLACK_HOLE_STATION_RIPPER_BONUS = .01;
/** 撕裂者超频 raises each complete 空间撕裂者 from 100 to this many energy/s. */
const SPACE_RIPPER_OVERCLOCK_ENERGY = 200;
/** Extra description line shown after 撕裂者超频 is researched. */
const SPACE_RIPPER_OVERCLOCK_DESC = '空间的连接点似乎不稳定...';
/** 高维存储 doubles hyperspace storage: +100% on the building's base contribution. */
const HIGHER_DIMENSIONAL_STORAGE_BONUS = 1;
/** 高维存储 adds this flat water storage to every funded hyperspace spaceport. */
const SPACEPORT_HIGHER_DIMENSIONAL_WATER = 16000;
/** Additive freight capacity percentages: asteroid bases +5% each, 高维存储 +100%. */
function calculateFreightCapacityMultiplier(state, asteroidBases) {
    return calculateAsteroidFreightMultiplier(asteroidBases)
        + (state.tech.includes('higherDimensionalStorage') ? HIGHER_DIMENSIONAL_STORAGE_BONUS : 0);
}
