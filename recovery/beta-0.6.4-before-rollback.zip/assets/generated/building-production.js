// GENERATED from src/simulation/building-production.ts — do not edit.






/** Technology-dependent presentation retains stable building and save identifiers. */
function calculateBuildingName(id, state) {
    return id === 'navigationBeacon' && state.tech.includes('spaceBroadcasting') ? '广播信标' : BUILDINGS[id].name;
}
const TOOL_JOBS = ['forage', 'lumber', 'quarry', 'mine'];
function countUsedWorkers(state) { return Object.values(state.workers).reduce((a, b) => a + b, 0); }
function calculateWorkerCapacity(id, state) {
    const building = BUILDINGS[id];
    if (id === 'theater')
        return (state.buildings.theater || 0) * (BUILDINGS.theater.artistSlots || 0) + (state.buildings.catCafe || 0) * (BUILDINGS.catCafe.artistSlots || 0);
    if (id === 'catCafe')
        return 0;
    if (id === 'foundry' || id === 'planetaryFoundry') {
        const planetary = state.buildings.planetaryFoundry || 0;
        // 恒星熔炉 adds two artisan positions each to the shared 工匠 job.
        return id === 'planetaryFoundry' ? planetary : (state.buildings.foundry || 0) * (BUILDINGS.foundry.slots || 2) + planetary + 2 * (state.buildings.stellarForge || 0);
    }
    return building.unlimited ? Infinity : state.buildings[id] * (building.slots ?? building.artistSlots ?? CONFIG.workersPerBuilding) + calculateGrantedJobSlots(id, state);
}
/** Buildings granting extra slots to another job (高科技工厂→水泥工人, 710研究站→科学家), per owned building. */
const JOB_SLOT_GRANTERS = Object.keys(BUILDINGS).filter(id => BUILDINGS[id].jobSlots);
function calculateGrantedJobSlots(id, state) {
    return JOB_SLOT_GRANTERS.reduce((sum, granter) => sum + (state.buildings[granter] || 0) * (BUILDINGS[granter].jobSlots?.[id] || 0), 0);
}
function calculateToolMultiplier(id, state) {
    if (id === 'coalMine')
        return state.tech.includes('steelTools') ? 1.5 : 1;
    return TOOL_JOBS.includes(id) ? state.tech.includes('steelTools') ? 1.5 : state.tech.includes('ironTools') ? 1.25 : 1 : 1;
}
/** Matches the legacy UI capability check, including object-identity automation rules. */
function hasContinuousEnergyInput(id, state) {
    const building = BUILDINGS[id];
    if (id === 'metalRefinery')
        return state.tech.includes('advancedMetalRefining');
    if (building.alwaysRunning)
        return false;
    if (building.moonSupport || building.support || building.toggleable)
        return true;
    if (id === 'mine' || id === 'coalMine' || id === 'lumber' || id === 'quarry')
        return state.tech.includes('automatedMining');
    if (id === 'cementWorkshop')
        return state.tech.includes('cementMixer');
    return !!(building.input && Object.keys(building.input).length);
}
function calculateBuildingInput(id, state) {
    if (id === 'navigationBeacon')
        return { energy: state.tech.includes('spaceBroadcasting') ? 3 : 2 };
    if (id === 'metalRefinery')
        return state.tech.includes('advancedMetalRefining') ? { energy: 4 } : {};
    if (id === 'aiSupercore')
        return { helium3: 25, energy: 100 };
    if (id === 'refinery' && state.tech.includes('crudeOilRefiningOptimization'))
        return { energy: 2 };
    const input = BUILDINGS[id].input || {};
    return applySpaceFuelDiscount(id, input, state);
}
function calculateTouristBase(state, inputs = null) {
    const cafes = inputs ? inputs.catCafe || 0 : Math.max(0, (state.buildings.catCafe || 0) - (state.stoppedBuildings?.catCafe || 0));
    return 2 * (state.buildings.theater || 0) + 5 * cafes + 4 * (state.arpaBuildings?.monument || 0);
}
/** Per-unit base output, including run-scoped 基因修饰 base-output genes. */
function calculateBuildingOutput(id, state, inputs = null) {
    const output = calculateRawBuildingOutput(id, state, inputs);
    const gene = calculateGeneOutputFactor(id, state);
    if (!gene || gene.factor === 1)
        return output;
    return Object.fromEntries(Object.entries(output).map(([resource, amount]) => [resource, amount * gene.factor]));
}
function calculateRawBuildingOutput(id, state, inputs) {
    if (id === 'iceMiningShip')
        return { water: state.tech.includes('icebreakingPlan') ? 1.25 : 1 };
    if (id === 'ecologicalDome')
        return { food: .25 };
    if (id === 'catCafe')
        return { cash: 5 + Math.floor(state.population / 10) * 5 };
    if (id === 'touristCenter')
        return { cash: calculateTouristBase(state, inputs) };
    const building = BUILDINGS[id], output = building.workerOutput || building.output || {};
    if (id === 'smelter')
        return { ...output, metal: ((state.tech.includes('electrochemicalSmelting') ? 1 : output.metal || 0) + (state.tech.includes('quantumTunnelingThermalProcessing') ? .1 : 0)) * (state.tech.includes('oxygenConverter') ? 1.2 : 1) * (state.tech.includes('geothermalFurnace') ? 1.5 : 1) };
    if (state.tech.includes('plasmaMining')) {
        if (id === 'iridiumMiningShip')
            return { iridium: .15 };
        if (id === 'ironMiningShip')
            return { iron: 4 };
        if (id === 'e710MiningShip')
            return { e710: .012 };
    }
    if (state.tech.includes('asteroidMiningOptimization')) {
        if (id === 'iridiumMiningShip')
            return { iridium: .1 };
        if (id === 'ironMiningShip')
            return { iron: 3 };
    }
    if (id === 'talosMoonMiningStation')
        return { ...output, neutron: (output.neutron || 0) * (1 + .05 * (state.buildings.miningDrone || 0)) };
    if (id === 'helium3Mine' && state.tech.includes('helium3ExtractionOptimization'))
        return { ...output, helium3: .25 };
    if (id === 'fissionGenerator' && state.tech.includes('breederReactor'))
        return { energy: 20 };
    if (id === 'spaceRipper' && state.tech.includes('ripperOverclock'))
        return { energy: SPACE_RIPPER_OVERCLOCK_ENERGY };
    // 引力转化 is a whole-sphere bonus, spread over the built segments so every settlement path agrees.
    if (id === 'penroseSphere' && state.tech.includes('gravityConversion') && (state.buildings.penroseSphere || 0) > 0 && state.blackHole) {
        return { energy: (output.energy || 0) + calculateGravityConversionEnergy(state) / state.buildings.penroseSphere };
    }
    if (id === 'refinery' && state.tech.includes('crudeOilRefiningOptimization'))
        return { oil: 1.5 };
    if (id === 'quarry' && state.buildings.metalRefinery > 0)
        return { ...output, aluminum: 1 };
    if (id === 'coalMine' && state.tech.includes('nuclearEnergy'))
        return { ...output, uranium: (output.coal || 0) * .05 };
    return output;
}
