// GENERATED from src/simulation/particle-overclock.ts — do not edit.

const fundedOverclockUnits = Symbol('fundedOverclockUnits');
/** Inject funded units into a read-only settlement context, never the saved state. */
function withPoweredParticleOverclock(state, units) {
    return { ...state, [fundedOverclockUnits]: units };
}
/** Only enabled stations increase each enabled station's power demand. */
function calculateParticleOverclockPower(state) {
    return 5 * Math.max(0, (state.buildings.particleOverclockStation || 0) - (state.stoppedBuildings?.particleOverclockStation || 0));
}
/** Reserve complete stations before ordinary output; fractional power grants no bonus. */
function settleParticleOverclockPower(state, pool, dt) {
    const owned = Math.max(0, state.buildings.particleOverclockStation || 0);
    const running = Math.max(0, owned - (state.stoppedBuildings?.particleOverclockStation || 0));
    const power = calculateParticleOverclockPower(state);
    const units = power > 0 ? Math.min(running, Math.floor((Math.max(0, pool.energy) + 1e-8) / (power * dt))) : 0;
    pool.energy = Math.max(0, pool.energy - units * power * dt);
    return units;
}
/** Normal bonus per accelerator (.10 baseline); imbalance ordinary bonus is this minus .05. */
function calculateAcceleratorBonus(state) {
    if (!state.buildings?.particleOverclockStation)
        return .1;
    const units = state[fundedOverclockUnits] ?? (state.resources && state.tech && state.stoppedBuildings
        ? calculateSupportPreview(state).particleOverclockUnits : 0);
    return .1 + units * (state.tech?.includes('advancedParticleOverclock') ? .025 : .02);
}
