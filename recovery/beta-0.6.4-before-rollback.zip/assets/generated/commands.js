// GENERATED from src/simulation/commands.ts — do not edit.













function createContainers(state, count) {
    const recipe = calculateContainerRecipe(state);
    if (!Number.isSafeInteger(count) || count < 1 || !Object.keys(recipe).every(id => isResourceUnlocked(id, state)))
        return 0;
    const ingredients = Object.entries(recipe);
    const amount = Math.min(count, calculateContainerCapacity(state) - state.containers, ...ingredients.map(([id, value]) => Math.floor((state.resources[id] + 1e-8) / value)));
    if (amount <= 0 || !payResourceCost(state.resources, Object.fromEntries(ingredients.map(([id, value]) => [id, value * amount]))))
        return 0;
    state.containers += amount;
    return amount;
}
/** The caller must clamp resources after capacity decreases. */
function changeContainerAssignment(state, id, delta) {
    if (!isContainerAssignable(id, state) || !Number.isSafeInteger(delta) || !delta)
        return 0;
    const resource = id;
    const amount = delta > 0 ? Math.min(delta, state.containers - countAssignedContainers(state)) : -Math.min(-delta, state.containerAssignments[resource]);
    if (amount)
        state.containerAssignments[resource] += amount;
    return amount;
}
function createAlloyContainers(state, count) {
    if (!state.tech.includes('superContainers') || !Number.isSafeInteger(count) || count < 1 || !isResourceUnlocked('alloy', state))
        return 0;
    const price = ALLOY_CONTAINER_RECIPE.alloy;
    const amount = Math.min(count, calculateAlloyContainerCapacity(state) - state.alloyContainers, Math.floor((state.resources.alloy + 1e-8) / price));
    if (amount <= 0 || !payResourceCost(state.resources, { alloy: price * amount }))
        return 0;
    state.alloyContainers += amount;
    return amount;
}
/** The caller must clamp resources after capacity decreases, exactly as for ordinary containers. */
function changeAlloyContainerAssignment(state, id, delta) {
    if (!state.tech.includes('superContainers') || !isContainerAssignable(id, state) || !Number.isSafeInteger(delta) || !delta)
        return 0;
    const resource = id;
    const amount = delta > 0 ? Math.min(delta, state.alloyContainers - countAssignedAlloyContainers(state)) : -Math.min(-delta, state.alloyContainerAssignments[resource]);
    if (amount)
        state.alloyContainerAssignments[resource] += amount;
    return amount;
}
function changeFactoryAssignment(state, id, delta) {
    if (!Number.isSafeInteger(delta) || !delta || !Object.hasOwn(state.lines, id) || (delta > 0 && !isFactoryLineUnlocked(id, state)))
        return 0;
    const line = id;
    const amount = delta > 0 ? Math.min(delta, calculateFactoryCapacity(state) - countAssignedLines(state)) : -Math.min(-delta, state.lines[line]);
    if (amount)
        state.lines[line] += amount;
    return amount;
}
/** Move 冶炼厂工位 between 钢冶炼 (delta > 0) and idle (delta < 0). */
function changeSmelterAssignment(state, delta) {
    if (!Number.isSafeInteger(delta) || !delta)
        return 0;
    const capacity = calculateSmelterSlotCapacity(state);
    const idle = Math.min(state.smelterIdle || 0, capacity);
    const amount = delta > 0 ? Math.min(delta, idle) : -Math.min(-delta, capacity - idle);
    state.smelterIdle = idle - amount;
    return amount;
}
function completeAsrielMission(state) {
    return completeRegionalMissionNow(state, 'asriel');
}
function completeKerberosMission(state) {
    return completeRegionalMissionNow(state, 'kerberos');
}
/** Backward-compatible immediate-only command; queued clicks use requestPurchaseModule. */
function completeSpaceMission(state, id) {
    return Object.hasOwn(SPACE_MISSIONS, id) && completeRegionalMissionNow(state, id);
}
function changeWorkerAssignment(state, id, delta) {
    if (!Object.hasOwn(BUILDINGS, id))
        return 0;
    const key = (id === 'catCafe' ? 'theater' : id === 'planetaryFoundry' ? 'foundry' : id), building = BUILDINGS[key];
    const jobUnlocked = state.tech.includes(building.tech) || (key === 'theater' && state.tech.includes(BUILDINGS.catCafe.tech));
    if ((!building.output && !building.workerOutput && !building.artistSlots && !building.craftSlots)
        || !jobUnlocked || !Number.isSafeInteger(delta) || !delta)
        return 0;
    const amount = delta > 0 ? Math.min(delta, Math.max(0, state.population - countUsedWorkers(state)), Math.max(0, calculateWorkerCapacity(key, state) - state.workers[key]))
        : -Math.min(-delta, state.workers[key]);
    if (!amount)
        return 0;
    state.workers[key] += amount;
    if (building.craftSlots)
        trimAssignedCraftWorkers(state);
    return amount;
}
/** Commands mutate only state; callers own persistence, logs and notifications. */
function changeTaxRate(state, value) {
    if (!Number.isFinite(value) || value < 0 || value > 30)
        return false;
    state.taxRate = value;
    return true;
}
function changeGovernment(state, id) {
    if (!Object.hasOwn(GOVERNMENTS, id))
        return false;
    const government = id;
    if (!state.tech.includes(GOVERNMENTS[government].tech) || state.government === government || reformCooldown(state) > 0)
        return false;
    state.government = government;
    state.lastReformTime = state.time;
    return true;
}
function craftManually(state, id, count) {
    if (isChallengeGeneActive(state, 'industrialFracture') || !Object.hasOwn(CRAFT_RECIPES, id) || !isResourceUnlocked(id, state))
        return 0;
    if (count !== 'max' && (!Number.isSafeInteger(count) || count <= 0))
        return 0;
    const craft = id, maximum = calculateMaxCraftable(craft, state);
    const amount = count === 'max' ? maximum : Math.min(count, maximum);
    if (!amount)
        return 0;
    for (const [resource, value] of Object.entries(CRAFT_RECIPES[craft].input))
        state.resources[resource] -= value * amount;
    state.resources[craft] += amount * calculateCraftingMultiplier(craft, state);
    return amount;
}
