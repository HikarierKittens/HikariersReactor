// GENERATED from src/simulation/e710-storage.ts — do not edit.

/** Only fully maintained containers provide storage; callers own the supplied pool. */
function calculateE710ContainerUnits(state, pool, dt = 1, fuelMultiplier = calculateSpaceFuelMultiplier(state)) {
    const running = Math.max(0, (state.buildings.e710Container || 0) - (state.stoppedBuildings?.e710Container || 0));
    return Math.min(running, Math.floor((Math.max(0, pool.helium3 || 0) + 1e-8) / (.5 * fuelMultiplier * dt)));
}
