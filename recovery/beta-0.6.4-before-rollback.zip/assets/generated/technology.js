// GENERATED from src/simulation/technology.ts — do not edit.

const TECH_KNOWLEDGE_COST_RANGES = {
    2: [300, 500], 3: [1000, 1200], 4: [2000, 3000], 5: [4000, 6000],
    6: [15000, 20000], 7: [30000, 35000], 8: [45000, 50000], 9: [70000, 80000],
    10: [90000, 120000], 11: [120000, 140000], 12: [150000, 180000],
};
function calculateTechnologyTier(id, memo = {}, technologies = TECHNOLOGIES) {
    if (memo[id] !== undefined)
        return memo[id];
    const tech = technologies[id];
    const tier = tech && Number.isInteger(tech.tier) ? tech.tier : tech?.pre.length
        ? Math.max(...tech.pre.map(parent => calculateTechnologyTier(parent, memo, technologies))) + 1 : 0;
    memo[id] = tier;
    return tier;
}
/** Preserve explicit exceptions and initial T0/T1 costs; called once at startup. */
function initializeTechnologyCosts(technologies = TECHNOLOGIES) {
    const memo = {};
    for (const [id, tech] of Object.entries(technologies)) {
        const range = TECH_KNOWLEDGE_COST_RANGES[calculateTechnologyTier(id, memo, technologies)];
        if (range)
            tech.cost.knowledge = tech.knowledgeCost ?? (range[0] + range[1]) / 2;
    }
}
