// GENERATED from src/simulation/moon.ts — do not edit.


/** Read-only allocation; caller owns power generation and maintenance payment. */
function allocateMoonSupport(state, resources, dt, fuelMultiplier = calculateSpaceFuelMultiplier(state)) {
    const running = (id) => Math.max(0, (state.buildings[id] || 0) - (state.stoppedBuildings[id] || 0));
    const baseUnits = Math.min(running('moonBase'), Math.floor((Math.max(0, resources.oil || 0) + 1e-8) / (2 * fuelMultiplier * dt)), Math.floor((Math.max(0, resources.energy || 0) + 1e-8) / (4 * dt)));
    // Enabled beacons reserve power after lunar bases; stopped beacons consume nothing.
    const beaconEnergy = calculateBuildingInput('navigationBeacon', state).energy || 2;
    const beaconUnits = Math.min(running('navigationBeacon'), Math.floor((Math.max(0, resources.energy - baseUnits * 4 * dt) + 1e-8) / (beaconEnergy * dt)));
    const capacity = baseUnits * 2 + beaconUnits;
    let available = capacity;
    const allocations = { iridiumMine: 0, helium3Mine: 0, moonObservatory: 0 };
    const priority = ['iridiumMine', 'helium3Mine', 'moonObservatory'];
    for (const id of priority) {
        allocations[id] = Math.min(running(id), available);
        available -= allocations[id];
    }
    return { capacity, used: capacity - available, available, baseUnits, beaconUnits, allocations };
}
